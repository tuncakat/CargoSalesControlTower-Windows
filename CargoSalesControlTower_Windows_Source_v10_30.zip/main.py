
from __future__ import annotations
import sys, math, json, os
from datetime import datetime
from pathlib import Path
import pandas as pd

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, QRectF, QMargins, QPointF, QPoint, QEvent
from PySide6.QtGui import QColor, QFont, QPainter, QPixmap, QPen, QPainterPath
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QFileDialog, QFrame, QGridLayout, QTabWidget,
    QTableView, QMessageBox, QHeaderView, QAbstractItemView, QProgressBar,
    QSizePolicy, QStackedWidget, QSplitter, QDialog, QDialogButtonBox, QGraphicsSimpleTextItem,
    QToolTip, QScrollArea, QMenu, QInputDialog
)
from PySide6.QtCharts import (
    QChart, QChartView, QLineSeries, QAreaSeries, QPieSeries, QPieSlice, QBarSeries, QBarSet, QLegend, QHorizontalPercentBarSeries,
    QBarCategoryAxis, QValueAxis
)

from cargo_engine import (
    load_comis_booking_list, load_comis_booking_lists, available_periods, filter_data, filter_period, kpis,
    agent_performance, destination_performance, recommended_actions, _capacity_for
)

APP_TITLE = "Weekly Sales & Action Dashboard"

NAVY = "#062A4D"
NAVY2 = "#0B3C68"
RED = "#D71920"
BG = "#F4F6F9"
BORDER = "#D7DEE8"
TEXT = "#13213B"
MUTED = "#6B778C"
GREEN = "#1F9D55"
AMBER = "#D99000"

QSS = f"""
QMainWindow, QWidget {{
    background: #031426;
    color: #E8EEF5;
    font-family: Segoe UI, Arial;
}}
QFrame#sidebar {{
    background: #04172A;
    border-right: 1px solid #17334D;
}}
QLabel#sidebarTitle {{
    color: white;
    font-size: 11px;
    font-weight: 700;
}}
QPushButton#nav {{
    background: transparent;
    color: #F2F6FA;
    text-align: left;
    padding: 16px 14px;
    border: none;
    font-size: 12px;
    font-weight: 600;
}}
QPushButton#nav:hover {{
    background: #0B2A45;
}}
QPushButton#navActive {{
    background: #E31B23;
    color: white;
    text-align: left;
    padding: 16px 14px;
    border: none;
    font-size: 12px;
    font-weight: 800;
}}
QFrame#header {{
    background: #031426;
    border-bottom: 1px solid #17334D;
}}
QLabel#appTitle {{
    color: white;
    font-size: 19px;
    font-weight: 900;
}}
QLabel#appSubtitle {{
    color: #A9B8C7;
    font-size: 10px;
}}
QLabel#filterLabel {{
    color: #B8C6D4;
    font-size: 8px;
    font-weight: 800;
}}
QFrame#filterBar {{
    background: #09223A;
    border: 1px solid #1E3D59;
    border-radius: 10px;
}}
QFrame#card, QFrame#panel {{
    background: #082138;
    border: 1px solid #284962;
    border-radius: 10px;
}}
QComboBox {{
    background: #0A2944;
    color: #F7FAFC;
    border: 1px solid #35546E;
    border-radius: 8px;
    padding: 6px 8px;
    min-width: 88px;
}}
QComboBox:hover {{
    border: 1px solid #5D7D99;
}}
QComboBox:disabled {{
    background: #071A2B;
    color: #5E7182;
    border: 1px solid #243B50;
}}
QComboBox QAbstractItemView {{
    background: #0A2944;
    color: white;
    selection-background-color: #E31B23;
    border: 1px solid #35546E;
}}
QPushButton#primary {{
    background: #147CE5;
    color: white;
    border: none;
    border-radius: 9px;
    padding: 9px 14px;
    font-weight: 800;
}}
QPushButton#primary:hover {{ background: #2A8CF0; }}
QPushButton#reset {{
    background: transparent;
    color: #E6EDF5;
    border: 1px solid #46627A;
    border-radius: 8px;
    padding: 8px 12px;
    font-weight: 700;
}}
QPushButton#reset:hover {{
    background: #12324D;
}}
QLabel#kpiTitle {{
    color: #D6E1EA;
    font-size: 9px;
    font-weight: 800;
}}
QLabel#kpiValue {{
    color: white;
    font-size: 21px;
    font-weight: 900;
}}
QLabel#kpiSub {{
    color: #A7B6C4;
    font-size: 8px;
}}
QLabel#deltaPos {{
    color: #3CE26E;
    font-size: 9px;
    font-weight: 800;
}}
QLabel#deltaNeg {{
    color: #FF5E66;
    font-size: 9px;
    font-weight: 800;
}}
QLabel#sectionTitle {{
    color: #F2F6FA;
    font-size: 11px;
    font-weight: 900;
}}
QTableView {{
    background: #0A2033;
    alternate-background-color: #0C263D;
    gridline-color: #1F3A51;
    border: 1px solid #27455D;
    color: #EAF1F7;
    selection-background-color: #143A5A;
}}
QHeaderView::section {{
    background: #0E2A43;
    color: #EAF1F7;
    padding: 5px;
    border: none;
    border-bottom: 1px solid #2A465E;
    font-size: 9px;
    font-weight: 800;
}}
QProgressBar {{
    border: 1px solid #35546E;
    border-radius: 6px;
    text-align: center;
    height: 14px;
    background: #0A2033;
    color: white;
}}
QProgressBar::chunk {{
    background: #1F77D0;
    border-radius: 5px;
}}

QFrame#brandHeader {{
    background: transparent;
    border: none;
}}
QLabel#brandEmblem {{
    color: white;
    background: transparent;
    border: none;
}}
QLabel#brandWordmark {{
    color: #FFFFFF;
    background: transparent;
    border: none;
    font-size: 15px;
    font-weight: 900;
}}
QLabel#brandAircraft {{
    color: rgba(255,255,255,55);
    background: transparent;
    border: none;
    font-size: 44px;
    font-weight: 400;
    padding-right: 8px;
}}

"""


class DonutChartView(QChartView):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.center_label = QLabel(self)
        self.center_label.setAlignment(Qt.AlignCenter)
        self.center_label.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.center_label.setStyleSheet(
            "color:#FFFFFF;background:transparent;font-size:16px;font-weight:900;"
        )
        self.center_label.setText("0\nAWBs")
        self.center_label.resize(120,70)
        self.center_label.show()

    def setCenterText(self, text):
        self.center_label.setText(text)
        self._position_center_label()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_center_label()

    def _position_center_label(self):
        w,h=self.center_label.width(),self.center_label.height()
        # Keep it centered slightly left because legend sits on right.
        cx=int(self.width()*0.42)
        cy=int(self.height()*0.50)
        self.center_label.move(cx-w//2,cy-h//2)

class DataFrameModel(QAbstractTableModel):
    def __init__(self, df=None):
        super().__init__()
        self.df = df if df is not None else pd.DataFrame()

    def set_df(self, df):
        self.beginResetModel()
        self.df = df.copy()
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return len(self.df)

    def columnCount(self, parent=QModelIndex()):
        return len(self.df.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        value = self.df.iloc[index.row(), index.column()]
        col = self.df.columns[index.column()]
        if role == Qt.DisplayRole:
            if pd.isna(value): return ""
            if col == "Flight Date":
                try: return pd.Timestamp(value).strftime("%d-%b-%Y")
                except: return str(value)
            if col in ("Revenue USD",): return f"${float(value):,.0f}"
            if col in ("UR USD/kg",): return f"${float(value):.2f}"
            if col in ("LF %",): return f"{float(value):.1%}"
            if col in ("CW Change",):
                try:
                    v = float(value)
                    return f"{'▲' if v >= 0 else '▼'} {abs(v):.1%}"
                except:
                    return ""
            if col == "Opportunity Score":
                try:
                    return f"{int(round(float(value)))}"
                except:
                    return ""
            if col in ("Capacity KG","Booked CW KG","Gap KG","CW KG"): return f"{float(value):,.1f}"
            return str(value)
        if role == Qt.ForegroundRole and col in ("Status","Priority","CW Change","Opportunity Score"):
            if col == "CW Change":
                try:
                    return QColor("#43D95B") if float(value) >= 0 else QColor("#FF3B45")
                except:
                    return QColor("#AFC0CF")
            if col == "Opportunity Score":
                try:
                    v=float(value)
                    if v >= 80: return QColor("#43D95B")
                    if v >= 60: return QColor("#E0B54A")
                    return QColor("#AFC0CF")
                except:
                    return QColor("#AFC0CF")
            if col == "Capacity Source":
                return QColor("#FFCC66") if str(value)=="MANUAL" else QColor("#8FA8BA")
            s = str(value)
            if s in ("OVERBOOKED","HIGH"): return QColor(RED)
            if s in ("LOW LF","MEDIUM"): return QColor(AMBER)
            if s in ("HIGH LF","INFO"): return QColor(GREEN)
        if role == Qt.FontRole and col in ("Status","Priority"):
            f = QFont(); f.setBold(True); return f
        return None

    def row_dict(self, row):
        if 0 <= row < len(self.df):
            return self.df.iloc[row].to_dict()
        return {}

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole: return None
        return str(self.df.columns[section]) if orientation == Qt.Horizontal else str(section+1)

class KpiCard(QFrame):
    ICONS = {
        "TK TONNAGE":"✈", "TK REVENUE (USD)":"$", "TK UNIT REVENUE":"↗",
        "FREIGHTER LF":"▣", "PAX LF":"✈", "FREIGHTER UR":"$", "PAX UR":"↗",
        "ONLINE SALES SHARE":"◎", "AWBs":"▤"
    }
    COLORS = {
        "TK TONNAGE":"#2D8CFF", "TK REVENUE (USD)":"#49B83E",
        "TK UNIT REVENUE":"#8B4BD8", "FREIGHTER LF":"#4AA63C",
        "PAX LF":"#E08717", "FREIGHTER UR":"#8B4BD8",
        "PAX UR":"#E31B23", "ONLINE SALES SHARE":"#1676D2", "AWBs":"#7B7B7B"
    }

    def __init__(self, title, unit=""):
        super().__init__()
        self.setObjectName("card")
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        lay = QVBoxLayout(self); lay.setContentsMargins(10,9,10,9); lay.setSpacing(2)

        head = QHBoxLayout()
        badge = QLabel(self.ICONS.get(title,"•"))
        badge.setAlignment(Qt.AlignCenter)
        badge.setFixedSize(24,24)
        badge.setStyleSheet(
            f"background:{self.COLORS.get(title,'#2D8CFF')};color:white;"
            "border-radius:12px;font-size:12px;font-weight:900;"
        )
        title_l = QLabel(title); title_l.setObjectName("kpiTitle")
        head.addWidget(badge); head.addWidget(title_l); head.addStretch()

        self.value = QLabel("—"); self.value.setObjectName("kpiValue")
        self.sub = QLabel(unit); self.sub.setObjectName("kpiSub")
        self.delta = QLabel("WoW —"); self.delta.setObjectName("deltaPos")
        lay.addLayout(head); lay.addWidget(self.value); lay.addWidget(self.sub); lay.addWidget(self.delta)

    def set_delta(self, d, label="WoW"):
        if d is None:
            self.delta.setText(f"{label} —")
            self.delta.setObjectName("deltaPos")
        else:
            arrow = "▲" if d >= 0 else "▼"
            self.delta.setText(f"{label}  {arrow} {abs(d):.1%}")
            self.delta.setObjectName("deltaPos" if d >= 0 else "deltaNeg")
        self.delta.style().unpolish(self.delta); self.delta.style().polish(self.delta)



class FlightDetailDialog(QDialog):
    def __init__(self, flight_row, awbs, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Flight Detail — {flight_row.get('Flight','')}")
        self.resize(1180, 760)
        self.setStyleSheet(QSS)

        self.flight_row = flight_row
        self.awbs = awbs.copy()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14,14,14,14)
        outer.setSpacing(10)

        # Header
        header = QFrame(); header.setObjectName("panel")
        hl = QHBoxLayout(header); hl.setContentsMargins(14,10,14,10)
        box = QVBoxLayout()
        title = QLabel(f"{flight_row.get('Flight','')}  •  {flight_row.get('Sector','')}")
        title.setStyleSheet("color:white;font-size:20px;font-weight:900;")
        meta = QLabel(
            f"{pd.Timestamp(flight_row.get('Flight Date')).strftime('%d %b %Y')}  •  "
            f"{flight_row.get('DOW','')}  •  {flight_row.get('Flight Type','')}"
        )
        meta.setStyleSheet("color:#AFC0CF;font-size:10px;")
        box.addWidget(title); box.addWidget(meta)
        hl.addLayout(box); hl.addStretch()
        outer.addWidget(header)

        # KPI row
        kgrid = QGridLayout()
        kgrid.setHorizontalSpacing(8)
        self.kpi_labels = {}
        specs = [
            ("Capacity KG","CAPACITY","KG"),
            ("Booked CW KG","BOOKED CW","KG"),
            ("LF %","LOAD FACTOR","%"),
            ("Revenue USD","REVENUE","USD"),
            ("UR USD/kg","UNIT REVENUE","USD/KG"),
            ("AWBs","AWBs","COUNT"),
            ("Gap KG","OPEN / GAP","KG"),
            ("General Cargo KG","GENERAL CARGO","KG"),
            ("Pharma KG","PHARMA","KG"),
            ("Other KG","OTHER","KG"),
        ]
        for i,(key,label,unit) in enumerate(specs):
            card=QFrame(); card.setObjectName("card")
            cl=QVBoxLayout(card); cl.setContentsMargins(10,8,10,8)
            t=QLabel(label); t.setObjectName("kpiTitle")
            v=QLabel("—"); v.setObjectName("kpiValue")
            u=QLabel(unit); u.setObjectName("kpiSub")
            cl.addWidget(t); cl.addWidget(v); cl.addWidget(u)
            kgrid.addWidget(card,i//5,i%5)
            self.kpi_labels[key]=v
        outer.addLayout(kgrid)

        # Context row
        context = QFrame(); context.setObjectName("panel")
        cx = QHBoxLayout(context); cx.setContentsMargins(12,8,12,8)
        self.context_label = QLabel("")
        self.context_label.setStyleSheet("color:#D6E0E8;font-size:10px;")
        self.context_label.setWordWrap(True)
        cx.addWidget(self.context_label)
        outer.addWidget(context)

        # AWB table — full-height flight manifest
        table_panel = QFrame(); table_panel.setObjectName("panel")
        tpl = QVBoxLayout(table_panel); tpl.setContentsMargins(10,8,10,8)
        ttl=QLabel("AWB LIST")
        ttl.setObjectName("sectionTitle")
        tpl.addWidget(ttl)

        self.awb_model = DataFrameModel()
        self.awb_table = QTableView()
        self.awb_table.setModel(self.awb_model)
        self.awb_table.setAlternatingRowColors(True)
        self.awb_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.awb_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.awb_table.verticalHeader().setVisible(False)
        self.awb_table.verticalHeader().setDefaultSectionSize(28)
        self.awb_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.awb_table.setSortingEnabled(True)
        self.awb_table.setMinimumHeight(390)
        tpl.addWidget(self.awb_table,1)
        outer.addWidget(table_panel,4)

        close=QPushButton("Close")
        close.setObjectName("reset")
        close.clicked.connect(self.accept)
        outer.addWidget(close,0,Qt.AlignRight)

        self.populate()

    def _commodity_bucket(self, value):
        s = str(value or "").strip().upper()
        pharma_keys = [
            "PHARMA","PHARMACEUTICAL","MEDICINE","MEDICAL","VACCINE",
            "TEMP CONTROL","TEMPERATURE CONTROL","HEALTHCARE","HEALTH CARE"
        ]
        if any(k in s for k in pharma_keys):
            return "Pharma"
        return "General Cargo"

    def populate(self):
        fr=self.flight_row
        total_cw = float(self.awbs["CW KG"].sum()) if (not self.awbs.empty and "CW KG" in self.awbs.columns) else 0.0
        general_cw = 0.0
        pharma_cw = 0.0
        other_cw = 0.0
        if not self.awbs.empty:
            tmp = self.awbs.copy()
            if "Cargo Category" in tmp.columns:
                cats = tmp["Cargo Category"].fillna("Other").astype(str)
            else:
                # Fallback to SCC when category was not precomputed.
                scc = tmp["SCC"].fillna("").astype(str).str.upper() if "SCC" in tmp.columns else pd.Series("", index=tmp.index)
                cats = pd.Series("Other", index=tmp.index)
                cats[scc.str.contains(r"(^|[,;/|\\s])PIL($|[,;/|\\s])", regex=True)] = "Pharma"
                cats[(cats=="Other") & scc.str.contains(r"(^|[,;/|\\s])GEN($|[,;/|\\s])", regex=True)] = "General Cargo"
            general_cw = float(tmp.loc[cats=="General Cargo","CW KG"].sum())
            pharma_cw = float(tmp.loc[cats=="Pharma","CW KG"].sum())
            other_cw = float(tmp.loc[~cats.isin(["General Cargo","Pharma"]),"CW KG"].sum())

        values = {
            "Capacity KG": f"{float(fr.get('Capacity KG',0)):,.0f}",
            "Booked CW KG": f"{float(fr.get('Booked CW KG',0)):,.0f}",
            "LF %": f"{float(fr.get('LF %',0)):.1%}",
            "Revenue USD": f"${float(fr.get('Revenue USD',0)):,.0f}",
            "UR USD/kg": f"${float(fr.get('UR USD/kg',0)):.2f}",
            "AWBs": f"{int(fr.get('AWBs',0))}",
            "Gap KG": f"{float(fr.get('Gap KG',0)):,.0f}",
            "General Cargo KG": f"{general_cw:,.0f}",
            "Pharma KG": f"{pharma_cw:,.0f}",
            "Other KG": f"{other_cw:,.0f}",
        }
        for k,v in values.items():
            self.kpi_labels[k].setText(v)

        a=self.awbs.copy()
        if a.empty:
            self.awb_model.set_df(pd.DataFrame(columns=[
                "AWB","Pieces","CW KG","SCC","Commodity","Origin","Destination",
                "Agent","Revenue USD","UR USD/kg","Source"
            ]))
            self.context_label.setText("No AWB records found for this flight.")
            return

        # Best-effort pieces extraction
        piece_col=None
        for c in ["Pieces","No. of Pieces","Piece","Pcs","Pieces No","Number of Pieces"]:
            if c in a.columns:
                piece_col=c
                break
        if piece_col is None:
            a["Pieces"]=0
            piece_col="Pieces"

        # Ensure commodity exists
        if "Commodity" not in a.columns:
            a["Commodity"]=""

        a["UR USD/kg"] = a.apply(
            lambda r: r["Revenue USD"]/r["CW KG"] if r.get("CW KG",0) else 0,
            axis=1
        )

        # Summary context
        top_agent = a.groupby("Agent")["CW KG"].sum().sort_values(ascending=False)
        top_dest = a.groupby("Destination")["CW KG"].sum().sort_values(ascending=False)
        src_mix = a.groupby("Source")["AWB"].count().sort_values(ascending=False)

        parts=[]
        if len(top_agent): parts.append(f"Top Agent: {top_agent.index[0]} ({top_agent.iloc[0]:,.0f} kg)")
        if len(top_dest): parts.append(f"Top Destination: {top_dest.index[0]} ({top_dest.iloc[0]:,.0f} kg)")
        if len(src_mix): parts.append(f"Main Source: {src_mix.index[0]} ({int(src_mix.iloc[0])} AWBs)")
        self.context_label.setText("  •  ".join(parts))

        out=pd.DataFrame({
            "AWB": a["AWB"].astype(str),
            "Pieces": a[piece_col],
            "CW KG": a["CW KG"],
            "SCC": a["SCC"].astype(str) if "SCC" in a.columns else "",
            "Commodity": a["Commodity"].astype(str),
            "Origin": a["Origin"].astype(str),
            "Destination": a["Destination"].astype(str),
            "Agent": a["Agent"].astype(str),
            "Revenue USD": a["Revenue USD"],
            "UR USD/kg": a["UR USD/kg"],
            "Source": a["Source"].astype(str),
        })
        self.awb_model.set_df(out)


class IntelligenceDialog(QDialog):
    def __init__(self, title, entity_name, current_awbs, previous_awbs, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(980, 720)
        self.setStyleSheet(QSS)
        self.current_awbs = current_awbs.copy()
        self.previous_awbs = previous_awbs.copy()

        outer = QVBoxLayout(self)
        head = QFrame(); head.setObjectName("panel")
        hl = QHBoxLayout(head)
        tbox = QVBoxLayout()
        title_lbl = QLabel(title.upper()); title_lbl.setObjectName("appTitle")
        name_lbl = QLabel(entity_name); name_lbl.setStyleSheet("color:#43D95B;font-size:18px;font-weight:900;")
        tbox.addWidget(title_lbl); tbox.addWidget(name_lbl)
        hl.addLayout(tbox); hl.addStretch()
        outer.addWidget(head)

        # KPI row
        kgrid = QGridLayout()
        self.kpis = {}
        specs = [("CW","CW KG"),("Revenue","Revenue USD"),("UR","UR USD/kg"),("AWBs","AWBs"),("WoW","WoW")]
        for i,(key,label) in enumerate(specs):
            c = QFrame(); c.setObjectName("card")
            cl = QVBoxLayout(c); cl.setContentsMargins(10,8,10,8)
            lab = QLabel(label); lab.setObjectName("kpiTitle")
            val = QLabel("—"); val.setObjectName("kpiValue")
            cl.addWidget(lab); cl.addWidget(val)
            self.kpis[key]=val
            kgrid.addWidget(c,0,i)
        outer.addLayout(kgrid)

        # Top row: distribution charts
        row = QHBoxLayout()
        self.dest_view = QChartView(); self.dest_view.setRenderHint(QPainter.Antialiasing)
        self.origin_view = QChartView(); self.origin_view.setRenderHint(QPainter.Antialiasing)
        self.source_view = QChartView(); self.source_view.setRenderHint(QPainter.Antialiasing)
        for title_txt, view in [("DESTINATION MIX",self.dest_view),("ORIGIN MIX",self.origin_view),("BOOKING SOURCE",self.source_view)]:
            p = QFrame(); p.setObjectName("panel")
            pl = QVBoxLayout(p); pl.setContentsMargins(8,6,8,6)
            lab=QLabel(title_txt); lab.setObjectName("sectionTitle")
            pl.addWidget(lab); pl.addWidget(view)
            row.addWidget(p)
        outer.addLayout(row,2)

        # Bottom: insight/actions + trend
        bottom = QHBoxLayout()
        p1 = QFrame(); p1.setObjectName("panel")
        l1 = QVBoxLayout(p1)
        l1.addWidget(QLabel("WEEKLY / MONTHLY CHANGE"))
        self.trend_view = QChartView(); self.trend_view.setRenderHint(QPainter.Antialiasing)
        l1.addWidget(self.trend_view)

        p2 = QFrame(); p2.setObjectName("panel")
        l2 = QVBoxLayout(p2)
        l2.addWidget(QLabel("OPPORTUNITIES / ALERTS"))
        self.insight = QLabel(); self.insight.setWordWrap(True)
        self.insight.setStyleSheet("color:#D7E2EB;font-size:11px;")
        l2.addWidget(self.insight)
        l2.addStretch()
        bottom.addWidget(p1,2); bottom.addWidget(p2,1)
        outer.addLayout(bottom,2)

        close = QPushButton("Close"); close.setObjectName("reset"); close.clicked.connect(self.accept)
        outer.addWidget(close,0,Qt.AlignRight)

        self.populate()

    def _donut(self, mapping, colors):
        series = QPieSeries(); series.setHoleSize(0.56); series.setPieSize(0.82)
        total = max(1, sum(mapping.values()))
        for i,(name,val) in enumerate(mapping.items()):
            sl = series.append(f"{name}  {val} ({val/total:.0%})", val)
            sl.setBrush(QColor(colors[i % len(colors)]))
            sl.setBorderColor(QColor("#DCE6EF"))
            sl.setBorderWidth(1)
        ch=QChart(); ch.setBackgroundBrush(QColor("#082138")); ch.setBackgroundVisible(True)
        ch.setPlotAreaBackgroundBrush(QColor("#082138")); ch.setPlotAreaBackgroundVisible(True)
        ch.addSeries(series); ch.legend().setAlignment(Qt.AlignBottom); ch.legend().setLabelColor(QColor("#DCE6EF"))
        ch.setMargins(QMargins(4,4,4,4))
        return ch

    def populate(self):
        cur=self.current_awbs
        prev=self.previous_awbs
        cw=float(cur["CW KG"].sum()) if not cur.empty else 0
        rev=float(cur["Revenue USD"].sum()) if not cur.empty else 0
        ur=rev/cw if cw else 0
        awbs=len(cur)
        pcw=float(prev["CW KG"].sum()) if not prev.empty else 0
        wow=(cw/pcw-1) if pcw else None

        self.kpis["CW"].setText(f"{cw:,.0f}")
        self.kpis["Revenue"].setText(f"${rev:,.0f}")
        self.kpis["UR"].setText(f"${ur:.2f}")
        self.kpis["AWBs"].setText(str(awbs))
        self.kpis["WoW"].setText("—" if wow is None else f"{'▲' if wow>=0 else '▼'} {abs(wow):.1%}")
        self.kpis["WoW"].setStyleSheet("color:#43D95B;" if (wow or 0)>=0 else "color:#FF3B45;")

        dest = cur.groupby("Destination")["AWB"].count().sort_values(ascending=False).head(6).to_dict() if not cur.empty else {}
        origin = cur.groupby("Origin")["AWB"].count().sort_values(ascending=False).head(6).to_dict() if not cur.empty else {}
        src = cur.groupby("Source")["AWB"].count().sort_values(ascending=False).to_dict() if not cur.empty else {}
        self.dest_view.setChart(self._donut(dest,["#2D8CFF","#E31B23","#22A690","#E18A10","#8B4BD8","#808B96"]))
        self.origin_view.setChart(self._donut(origin,["#2D8CFF","#22A690","#E18A10","#8B4BD8"]))
        self.source_view.setChart(self._donut(src,["#E31B23","#E18A10","#4B6073"]))

        # weekly recent trend from current + prev aggregate
        series=QLineSeries(); series.setName("CW KG"); series.setColor(QColor("#2D8CFF"))
        series.append(0,pcw); series.append(1,cw)
        ch=QChart(); ch.setBackgroundBrush(QColor("#082138")); ch.setBackgroundVisible(True)
        ch.addSeries(series)
        ax=QBarCategoryAxis(); ax.append(["Previous","Current"]); ax.setLabelsColor(QColor("#AFC0CF")); ch.addAxis(ax,Qt.AlignBottom); series.attachAxis(ax)
        ay=QValueAxis(); ay.setLabelsColor(QColor("#AFC0CF")); ay.setGridLineColor(QColor("#1F3A51")); ch.addAxis(ay,Qt.AlignLeft); series.attachAxis(ay)
        ch.legend().setLabelColor(QColor("#DCE6EF")); ch.setMargins(QMargins(4,4,4,4))
        self.trend_view.setChart(ch)

        # insights
        lines=[]
        if wow is not None:
            if wow <= -0.15:
                lines.append(f"🔴 CW dropped {abs(wow):.1%} vs previous period. Re-engage top historical accounts immediately.")
            elif wow >= 0.15:
                lines.append(f"🟢 CW increased {wow:.1%} vs previous period. Protect momentum and secure repeat bookings.")
            else:
                lines.append(f"🟡 CW changed {wow:+.1%} vs previous period. Performance is relatively stable.")
        if not cur.empty:
            topd = cur.groupby("Destination")["CW KG"].sum().sort_values(ascending=False)
            if len(topd):
                lines.append(f"🟢 Top destination: {topd.index[0]} ({topd.iloc[0]:,.0f} kg).")
            tops = cur.groupby("Source")["AWB"].count().sort_values(ascending=False)
            if len(tops):
                lines.append(f"🔵 Main booking source: {tops.index[0]} ({int(tops.iloc[0])} AWBs).")
            topo = cur.groupby("Origin")["CW KG"].sum().sort_values(ascending=False)
            if len(topo):
                lines.append(f"🟢 Main origin: {topo.index[0]} ({topo.iloc[0]:,.0f} kg).")
        if ur < 1.5 and cw > 0:
            lines.append("🔴 Unit revenue is low. Review pricing and low-yield traffic before accepting additional volume.")
        self.insight.setText("\n\n".join(lines) if lines else "No material alert for this selection.")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Weekly Sales & Action Dashboard")
        self.resize(1440, 900)
        self.setMinimumSize(1180, 720)
        self.data = None
        self.source_filter = None
        self.commodity_filter = None
        self.entity_filter_context = None

        # Persistent manual capacity overrides live outside the .app bundle,
        # so they survive app restarts and future version replacements.
        self.capacity_overrides = self._load_capacity_overrides()

        shell = QWidget()
        self.setCentralWidget(shell)
        main = QHBoxLayout(shell); main.setContentsMargins(0,0,0,0); main.setSpacing(0)

        # Sidebar
        sidebar = QFrame(); sidebar.setObjectName("sidebar"); sidebar.setFixedWidth(155)
        s = QVBoxLayout(sidebar); s.setContentsMargins(0,0,0,0); s.setSpacing(0)
        # Premium integrated brand header — no boxed raster image.
        brand = QFrame()
        brand.setObjectName("brandHeader")
        brand.setFixedHeight(118)
        bl = QVBoxLayout(brand)
        bl.setContentsMargins(12,10,10,2)
        bl.setSpacing(0)

        top = QHBoxLayout()
        top.setSpacing(8)

        emblem = QLabel()
        emblem.setObjectName("brandEmblem")
        emblem.setAlignment(Qt.AlignCenter)
        emblem.setFixedSize(46,46)
        _brand_icon_path = Path(__file__).resolve().parent / "assets" / "aircraft_brand_emblem.png"
        _brand_pix = QPixmap(str(_brand_icon_path))
        if not _brand_pix.isNull():
            emblem.setPixmap(_brand_pix.scaled(44,44,Qt.KeepAspectRatio,Qt.SmoothTransformation))

        wordmark = QLabel("TURKISH\nCARGO")
        wordmark.setObjectName("brandWordmark")
        wordmark.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        top.addWidget(emblem,0,Qt.AlignTop)
        top.addWidget(wordmark,1)
        bl.addLayout(top)

        aircraft = QLabel("")
        aircraft.setFixedHeight(34)
        bl.addWidget(aircraft)

        s.addWidget(brand)

        navs = [
            "01  Executive\n      Overview",
            "02  Flight\n      Performance",
            "03  Destination\n      Intelligence",
            "04  Agent\n      Intelligence",
            "05  Revenue &\n      Pricing",
            "06  Action Center\n      (Recommended)",
        ]
        self.nav_buttons = []
        for i, text in enumerate(navs):
            b = QPushButton(text); b.setObjectName("navActive" if i==0 else "nav")
            b.clicked.connect(lambda _, idx=i: self.switch_page(idx))
            self.nav_buttons.append(b); s.addWidget(b)

        # Compact import/data-quality summary in the left sidebar.
        self.import_summary_box = QFrame()
        self.import_summary_box.setObjectName("importSummaryBox")
        self.import_summary_box.setStyleSheet(
            "QFrame#importSummaryBox{background:#071F34;border:1px solid #315875;"
            "border-radius:8px;margin:7px 8px 4px 8px;}"
        )
        isl=QVBoxLayout(self.import_summary_box)
        isl.setContentsMargins(9,8,9,8)
        isl.setSpacing(2)

        sum_title=QLabel("DATA SUMMARY")
        sum_title.setStyleSheet("color:#DDEAF3;font-size:8px;font-weight:900;")
        isl.addWidget(sum_title)

        self.import_summary = QLabel(
            "No booking files imported yet."
        )
        self.import_summary.setWordWrap(True)
        self.import_summary.setStyleSheet(
            "color:#D5E2EC;font-size:8px;line-height:1.2;background:transparent;border:0px;"
        )
        self.import_summary.setMinimumHeight(118)
        self.import_summary.setMaximumHeight(175)
        isl.addWidget(self.import_summary)
        s.addWidget(self.import_summary_box)

        s.addStretch()
        self.update_box = QFrame()
        self.update_box.setStyleSheet(
            "QFrame{background:#071C30;border:1px solid #50677D;border-radius:8px;margin:8px;}"
        )
        ub = QVBoxLayout(self.update_box); ub.setContentsMargins(10,10,10,10); ub.setSpacing(3)
        u1 = QLabel("LAST UPDATE")
        u1.setStyleSheet("color:#AFC0CF;font-size:8px;font-weight:800;")
        self.last_update_value = QLabel("—")
        self.last_update_value.setStyleSheet("color:white;font-size:10px;font-weight:800;")
        self.last_update_value.setWordWrap(True)
        self.last_update_file = QLabel("")
        self.last_update_file.setStyleSheet("color:#8FA5B8;font-size:8px;")
        self.last_update_file.setWordWrap(True)
        ub.addWidget(u1); ub.addWidget(self.last_update_value); ub.addWidget(self.last_update_file)
        s.addWidget(self.update_box)

        self.data_asof = QLabel("")
        self.data_asof.setVisible(False)
        s.addWidget(self.data_asof)
        main.addWidget(sidebar)

        # Main right area
        right = QWidget()
        r = QVBoxLayout(right); r.setContentsMargins(0,0,0,0); r.setSpacing(0)
        header = QFrame(); header.setObjectName("header"); header.setFixedHeight(60)
        hl = QHBoxLayout(header); hl.setContentsMargins(18,0,18,0)
        titlebox = QVBoxLayout()
        title = QLabel("WEEKLY SALES & ACTION DASHBOARD"); title.setObjectName("appTitle")
        subtitle = QLabel("Real-time Sales Performance, Key Insights & Recommended Actions")
        subtitle.setObjectName("appSubtitle")
        titlebox.addWidget(title); titlebox.addWidget(subtitle)
        hl.addLayout(titlebox); hl.addStretch()
        self.header_status = QLabel("Data as of: —")
        self.header_status.setStyleSheet("color:#B8C6D4;font-size:9px;")
        hl.addWidget(self.header_status)
        self.export_btn = QPushButton("⇩  Export")
        self.export_btn.setObjectName("reset")
        self.export_btn.setMinimumWidth(92); self.export_btn.setMaximumWidth(110)
        self.export_btn.clicked.connect(self.export_current_view)
        hl.addWidget(self.export_btn)
        r.addWidget(header)

        body = QWidget()
        bl = QVBoxLayout(body); bl.setContentsMargins(8,8,8,8); bl.setSpacing(6)
        r.addWidget(body,1)
        main.addWidget(right,1)

        # Filter bar
        filterbar = QFrame(); filterbar.setObjectName("filterBar")
        fl = QHBoxLayout(filterbar); fl.setContentsMargins(9,8,9,8); fl.setSpacing(6)
        self.period_combo = QComboBox(); self.period_combo.addItems(["Weekly","Monthly","Yearly"])
        self.week_combo = QComboBox()
        self.month_combo = QComboBox(); self.month_combo.addItems(["January","February","March","April","May","June","July","August","September","October","November","December"])
        self.year_combo = QComboBox()
        self.view_combo = QComboBox(); self.view_combo.addItems(["All","Freighter","Pax"]); self.view_combo.hide()
        self.view_segment = QFrame()
        self.view_segment.setStyleSheet(
            "QFrame{background:#0A2944;border:1px solid #35546E;border-radius:8px;}"
            "QPushButton{background:transparent;color:#F2F6FA;border:none;padding:7px 14px;}"
            "QPushButton:checked{background:#E31B23;color:white;border-radius:6px;font-weight:800;}"
        )
        vseg = QHBoxLayout(self.view_segment); vseg.setContentsMargins(2,2,2,2); vseg.setSpacing(0)
        self.view_buttons = {}
        for _name in ["All","Freighter","Pax"]:
            _b = QPushButton(_name); _b.setCheckable(True)
            if _name == "All": _b.setChecked(True)
            _b.clicked.connect(lambda checked, n=_name: self.set_view_segment(n))
            self.view_buttons[_name] = _b
            vseg.addWidget(_b)
        self.origin_combo = QComboBox(); self.origin_combo.addItems(["All","ARN","GOT","MMX"])
        for _c in [self.period_combo,self.week_combo,self.month_combo,self.year_combo,self.view_combo,self.origin_combo]:
            _c.setMinimumWidth(0)
            _c.setMaximumWidth(118)
            _c.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.dest_combo = QComboBox(); self.dest_combo.addItems(["All"])
        self.agent_combo = QComboBox(); self.agent_combo.addItems(["All"])
        for _c in [self.dest_combo,self.agent_combo]:
            _c.setMinimumWidth(0)
            _c.setMaximumWidth(128)
            _c.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        for label, combo in [
            ("PERIOD",self.period_combo),("WEEK",self.week_combo),("MONTH",self.month_combo),("YEAR",self.year_combo),
            ("ORIGIN",self.origin_combo),("DESTINATION",self.dest_combo),("AGENT",self.agent_combo)
        ]:
            box=QVBoxLayout(); lab=QLabel(label); lab.setObjectName("filterLabel")
            box.addWidget(lab); box.addWidget(combo); fl.addLayout(box)

        viewbox = QVBoxLayout()
        viewlab = QLabel("VIEW"); viewlab.setObjectName("filterLabel")
        viewbox.addWidget(viewlab); viewbox.addWidget(self.view_segment)
        fl.insertLayout(4, viewbox)
        self.import_btn=QPushButton("Import Booking List"); self.import_btn.setObjectName("primary")
        self.import_btn.setMinimumWidth(160); self.import_btn.setMaximumWidth(180); self.import_btn.clicked.connect(self.import_file); fl.addWidget(self.import_btn)
        self.clear_btn=QPushButton("← Back to All"); self.clear_btn.setObjectName("reset")
        self.clear_btn.setMinimumWidth(110); self.clear_btn.setMaximumWidth(125)
        self.clear_btn.clicked.connect(self.clear_drilldown)
        self.clear_btn.setVisible(False)
        fl.addWidget(self.clear_btn)

        self.reset_btn=QPushButton("Reset Filters"); self.reset_btn.setObjectName("reset")
        self.reset_btn.setMinimumWidth(112); self.reset_btn.setMaximumWidth(125); self.reset_btn.clicked.connect(self.reset_filters); fl.addWidget(self.reset_btn)
        bl.addWidget(filterbar)

        # Stacked pages
        self.pages=QStackedWidget()
        bl.addWidget(self.pages,1)
        self.pages.addWidget(self.build_overview())
        self.pages.addWidget(self.build_table_page("Flight Performance","flight"))
        self.pages.addWidget(self.build_table_page("Destination Intelligence","dest"))
        self.pages.addWidget(self.build_table_page("Agent Intelligence","agent"))
        self.pages.addWidget(self.build_revenue_page())
        self.pages.addWidget(self.build_table_page("Action Center","actions"))

        self.update_period_controls()
        self._initialize_empty_charts()

        for c in [self.period_combo,self.week_combo,self.month_combo,self.year_combo,self.view_combo,self.origin_combo,self.dest_combo,self.agent_combo]:
            c.currentIndexChanged.connect(self.refresh)
        self.month_combo.setCurrentIndex(7)
        self.update_period_controls()

    def panel(self, title):
        p=QFrame(); p.setObjectName("panel")
        l=QVBoxLayout(p); l.setContentsMargins(10,8,10,8)
        t=QLabel(title); t.setObjectName("sectionTitle"); l.addWidget(t)
        return p,l

    def _initialize_empty_charts(self):
        # Executive Overview uses QLabel + QPixmap canvases for stability.
        # Do not call QChartView.setChart() on these widgets.
        for view in [self.cw_view, self.revenue_view, self.lf_view]:
            view.clear()
            view.setStyleSheet("background:#061D31;border:0px;")


    def build_overview(self):
        w=QWidget(); lay=QVBoxLayout(w); lay.setContentsMargins(0,0,0,0); lay.setSpacing(7)

        # KPI row
        grid=QGridLayout(); grid.setHorizontalSpacing(5)
        self.cards={}
        kpispec=[
            ("Booked CW","TK TONNAGE","KG"),
            ("Revenue","TK REVENUE (USD)","USD"),
            ("Overall UR","TK UNIT REVENUE","USD/KG"),
            ("Freighter LF","FREIGHTER LF","%"),
            ("Pax LF","PAX LF","%"),
            ("Freighter UR","FREIGHTER UR","USD/KG"),
            ("Pax UR","PAX UR","USD/KG"),
            ("Online Share","ONLINE SALES SHARE","%"),
            ("Pharma Share","PHARMA SHARE","% CW"),
            ("Pharma Tonnage","PHARMA TONNAGE","TON"),
            ("General Cargo Share","GENERAL CARGO","% CW"),
            ("AWBs","AWBs","COUNT"),
        ]
        # Responsive KPI layout: 6 cards first row, remaining cards second row.
        # This keeps titles and values readable on 1440px and Retina-scaled screens.
        for i,(key,title,unit) in enumerate(kpispec):
            c=KpiCard(title,unit)
            c.setMinimumWidth(0)
            c.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
            self.cards[key]=c
            row=0 if i<6 else 1
            col=i if i<6 else i-6
            grid.addWidget(c,row,col)
        lay.addLayout(grid)

        # Charts row — separate business trends
        charts=QHBoxLayout()
        charts.setSpacing(8)

        pcw,lcw=self.panel("CW TREND")
        self.cw_view=QLabel()
        self.cw_view.setAlignment(Qt.AlignCenter)
        self.cw_view.setMinimumWidth(0)
        self.cw_view.setMinimumHeight(142)
        self.cw_view.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        self.cw_view.setMouseTracking(True)
        self.cw_view.installEventFilter(self)
        lcw.addWidget(self.cw_view)

        prev,lrev=self.panel("REVENUE TREND")
        self.revenue_view=QLabel()
        self.revenue_view.setAlignment(Qt.AlignCenter)
        self.revenue_view.setMinimumWidth(0)
        self.revenue_view.setMinimumHeight(142)
        self.revenue_view.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        self.revenue_view.setMouseTracking(True)
        self.revenue_view.installEventFilter(self)
        lrev.addWidget(self.revenue_view)

        plf,llf=self.panel("LF TREND (%)")
        self.lf_view=QLabel()
        self.lf_view.setAlignment(Qt.AlignCenter)
        self.lf_view.setMinimumWidth(0)
        self.lf_view.setMinimumHeight(142)
        self.lf_view.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        self.lf_view.setMouseTracking(True)
        self.lf_view.installEventFilter(self)
        llf.addWidget(self.lf_view)

        p3,l3=self.panel("TOP SALES OPPORTUNITIES")
        self.opportunity_model=DataFrameModel()
        self.opportunity_table=self.make_table(self.opportunity_model)
        self.opportunity_table.setStyleSheet(
            self.opportunity_table.styleSheet()+
            " QTableView{font-size:7px;} QHeaderView::section{font-size:7px;}"
        )
        self.opportunity_table.verticalHeader().setDefaultSectionSize(21)
        self.opportunity_table.verticalHeader().setMinimumSectionSize(20)
        self.opportunity_table.horizontalHeader().setFixedHeight(21)
        self.opportunity_table.setMinimumHeight(142)
        self.opportunity_table.setMaximumHeight(165)
        self.opportunity_table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.opportunity_table.clicked.connect(self.on_opportunity_clicked)
        self.opportunity_table.doubleClicked.connect(self.on_opportunity_double_clicked)
        l3.addWidget(self.opportunity_table,1)
        self.opportunity_footer=QLabel("Click to filter  •  Double-click for Destination Intelligence")
        self.opportunity_footer.setAlignment(Qt.AlignCenter)
        self.opportunity_footer.setStyleSheet("color:#71889A;font-size:7px;background:transparent;border:0px;")
        l3.addWidget(self.opportunity_footer)

        for _p in [pcw,prev,plf,p3]:
            _p.setMinimumWidth(0)
            _p.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        charts.addWidget(pcw,3)
        charts.addWidget(prev,3)
        charts.addWidget(plf,3)
        charts.addWidget(p3,4)
        charts.setStretch(0,3); charts.setStretch(1,3); charts.setStretch(2,3); charts.setStretch(3,4)
        self._trend_hover_data={}
        self._trend_tooltip=QLabel(self)
        self._trend_tooltip.setWindowFlags(Qt.ToolTip)
        self._trend_tooltip.setAttribute(Qt.WA_ShowWithoutActivating)
        self._trend_tooltip.setStyleSheet(
            "QLabel{background:#FFFFFF;color:#0B1726;border:1px solid #A7B7C7;"
            "border-radius:5px;padding:7px 9px;font-size:10px;font-weight:700;}"
        )
        self._trend_tooltip.hide()
        lay.addLayout(charts,12)

        # Intelligence row
        intel=QHBoxLayout()
        pa=QFrame(); pa.setObjectName("panel")
        la=QVBoxLayout(pa); la.setContentsMargins(10,8,10,8); la.setSpacing(5)
        agent_title_row=QHBoxLayout()
        self.agent_over_title=QLabel("TOP AGENTS — CW CHANGE (WoW)")
        self.agent_over_title.setObjectName("sectionTitle")
        self.agent_view_all=QPushButton("View All")
        self.agent_view_all.setObjectName("reset")
        self.agent_view_all.setFixedSize(68,22)
        self.agent_view_all.setStyleSheet(
            "QPushButton{background:#0B2942;color:#F2F6FA;border:1px solid #49657C;"
            "border-radius:6px;padding:0px;font-size:8px;font-weight:800;}"
            "QPushButton:hover{background:#123754;}"
        )
        self.agent_view_all.clicked.connect(lambda: self.switch_page(3))
        agent_title_row.setContentsMargins(0,0,0,0)
        agent_title_row.setSpacing(6)
        agent_title_row.addWidget(self.agent_over_title,1,Qt.AlignVCenter)
        agent_title_row.addWidget(self.agent_view_all,0,Qt.AlignRight|Qt.AlignVCenter)
        la.addLayout(agent_title_row)
        self.agent_over_model=DataFrameModel()
        self.agent_over=self.make_table(self.agent_over_model)
        self.agent_over.setStyleSheet(self.agent_over.styleSheet()+" QTableView{font-size:8px;} QHeaderView::section{font-size:8px;}")
        self.agent_over.verticalHeader().setDefaultSectionSize(25)
        self.agent_over.verticalHeader().setMinimumSectionSize(24)
        self.agent_over.horizontalHeader().setFixedHeight(21)
        self.agent_over.setMinimumHeight(154)
        self.agent_over.setMaximumHeight(176)
        self.agent_over.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        la.addWidget(self.agent_over,1)
        self.agent_over_footer=QLabel("Top 5 shown  •  View All for full agent list")
        self.agent_over_footer.setAlignment(Qt.AlignRight)
        self.agent_over_footer.setStyleSheet("color:#71889A;font-size:7px;background:transparent;border:0px;")
        la.addWidget(self.agent_over_footer)
        self.agent_over.clicked.connect(self.on_agent_overview_clicked)

        pdst=QFrame(); pdst.setObjectName("panel")
        ld=QVBoxLayout(pdst); ld.setContentsMargins(10,8,10,8); ld.setSpacing(5)
        dest_title_row=QHBoxLayout()
        self.dest_over_title=QLabel("TOP DESTINATIONS — CW CHANGE (WoW)")
        self.dest_over_title.setObjectName("sectionTitle")
        self.dest_view_all=QPushButton("View All")
        self.dest_view_all.setObjectName("reset")
        self.dest_view_all.setFixedSize(68,22)
        self.dest_view_all.setStyleSheet(
            "QPushButton{background:#0B2942;color:#F2F6FA;border:1px solid #49657C;"
            "border-radius:6px;padding:0px;font-size:8px;font-weight:800;}"
            "QPushButton:hover{background:#123754;}"
        )
        self.dest_view_all.clicked.connect(lambda: self.switch_page(2))
        dest_title_row.setContentsMargins(0,0,0,0)
        dest_title_row.setSpacing(6)
        dest_title_row.addWidget(self.dest_over_title,1,Qt.AlignVCenter)
        dest_title_row.addWidget(self.dest_view_all,0,Qt.AlignRight|Qt.AlignVCenter)
        ld.addLayout(dest_title_row)
        self.dest_over_model=DataFrameModel()
        self.dest_over=self.make_table(self.dest_over_model)
        self.dest_over.setStyleSheet(self.dest_over.styleSheet()+" QTableView{font-size:8px;} QHeaderView::section{font-size:8px;}")
        self.dest_over.verticalHeader().setDefaultSectionSize(25)
        self.dest_over.verticalHeader().setMinimumSectionSize(24)
        self.dest_over.horizontalHeader().setFixedHeight(21)
        self.dest_over.setMinimumHeight(154)
        self.dest_over.setMaximumHeight(176)
        self.dest_over.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        ld.addWidget(self.dest_over,1)
        self.dest_over_footer=QLabel("Top 5 shown  •  View All for full destination list")
        self.dest_over_footer.setAlignment(Qt.AlignRight)
        self.dest_over_footer.setStyleSheet("color:#71889A;font-size:7px;background:transparent;border:0px;")
        ld.addWidget(self.dest_over_footer)
        self.dest_over.clicked.connect(self.on_destination_overview_clicked)

        pact,lact=self.panel("EXECUTIVE INSIGHT & ALERTS")
        self.insight_scroll=QScrollArea()
        self.insight_scroll.setWidgetResizable(True)
        self.insight_scroll.setFrameShape(QFrame.NoFrame)
        self.insight_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.insight_scroll.setStyleSheet(
            "QScrollArea{background:#061D31;border:0px;}"
            "QScrollBar:vertical{background:#071C30;width:7px;border:0px;}"
            "QScrollBar::handle:vertical{background:#35546E;border-radius:3px;min-height:22px;}"
        )
        self.insight_container=QFrame()
        self.insight_container.setStyleSheet("background:#061D31;border:0px;")
        self.insight_layout=QVBoxLayout(self.insight_container)
        self.insight_layout.setContentsMargins(3,3,3,3)
        self.insight_layout.setSpacing(4)
        self.insight_empty=QLabel("Import data to generate executive insights.")
        self.insight_empty.setStyleSheet("color:#8FA8BA;font-size:8px;padding:6px;")
        self.insight_layout.addWidget(self.insight_empty)
        self.insight_layout.addStretch()
        self.insight_scroll.setWidget(self.insight_container)
        lact.addWidget(self.insight_scroll)
        for _p in [pa,pdst,pact]:
            _p.setMinimumWidth(0)
            _p.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        intel.addWidget(pa,4); intel.addWidget(pdst,4); intel.addWidget(pact,3)
        lay.addLayout(intel,30)

        # Bottom actions strip — target executive layout
        pb,lb=self.panel("KEY TAKEAWAYS / REQUIRED ACTIONS")
        cards=QHBoxLayout()
        cards.setSpacing(10)
        self.action_cards=[]

        action_specs = [
            ("✈", "OPEN FREIGHTER CAPACITY", "#BFD7F5", "View Flights"),
            ("$", "LOW UR AGENTS", "#F47B0B", "View Agents"),
            ("◎", "GROWING DESTINATIONS", "#49C64B", "View Destinations"),
            ("↘", "DECLINING DESTINATIONS", "#FF2B2B", "View Destinations"),
        ]

        for idx,(icon_txt,title,color,button_txt) in enumerate(action_specs):
            card=QFrame()
            card.setObjectName("card")
            card.setMinimumWidth(0)
            card.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
            cl=QVBoxLayout(card)
            cl.setContentsMargins(12,8,12,8)
            cl.setSpacing(4)

            top=QHBoxLayout()
            icon=QLabel(icon_txt)
            icon.setAlignment(Qt.AlignCenter)
            icon.setFixedSize(46,46)
            icon.setStyleSheet(
                f"color:{color};font-size:28px;font-weight:900;"
                "background:transparent;border:none;"
            )

            title_box=QVBoxLayout()
            title_lbl=QLabel(title)
            title_lbl.setStyleSheet("color:#F5F8FB;font-size:8px;font-weight:900;")
            metric_row=QHBoxLayout()
            metric=QLabel("—")
            metric.setStyleSheet("color:#FFFFFF;font-size:18px;font-weight:900;")
            unit=QLabel("")
            unit.setStyleSheet("color:#D0D9E2;font-size:10px;font-weight:700;padding-top:8px;")
            metric_row.addWidget(metric)
            metric_row.addWidget(unit)
            metric_row.addStretch()
            title_box.addWidget(title_lbl)
            title_box.addLayout(metric_row)

            top.addWidget(icon)
            top.addLayout(title_box,1)
            cl.addLayout(top)

            body=QLabel("—")
            body.setWordWrap(True)
            body.setStyleSheet("color:#D1DAE3;font-size:9px;line-height:1.15;")
            cl.addWidget(body)

            btn=QPushButton(button_txt)
            btn.setObjectName("reset")
            btn.setMinimumHeight(25)
            btn.setMaximumHeight(27)
            if idx==0:
                btn.clicked.connect(lambda: self.switch_page(1))
            elif idx==1:
                btn.clicked.connect(lambda: self.switch_page(3))
            elif idx==2:
                btn.clicked.connect(lambda: self.switch_page(2))
            else:
                btn.clicked.connect(lambda: self.switch_page(2))
            cl.addWidget(btn)

            cards.addWidget(card)
            self.action_cards.append({
                "icon": icon, "title": title_lbl, "metric": metric,
                "unit": unit, "body": body, "button": btn
            })

        total=QFrame()
        total.setMinimumWidth(205)
        total.setMaximumWidth(235)
        total.setStyleSheet("background:#C90008;border:1px solid #F03338;border-radius:12px;")
        tl=QVBoxLayout(total)
        tl.setContentsMargins(14,12,14,12)
        tl.setSpacing(8)
        tt=QLabel("TOTAL RECOMMENDED ACTIONS")
        tt.setAlignment(Qt.AlignCenter)
        tt.setStyleSheet("color:white;font-size:9px;font-weight:900;")
        self.total_actions=QLabel("0")
        self.total_actions.setAlignment(Qt.AlignCenter)
        self.total_actions.setStyleSheet("color:white;font-size:28px;font-weight:900;")
        go=QPushButton("Go to Action Center  →")
        go.setObjectName("reset")
        go.setMinimumWidth(180)
        go.clicked.connect(lambda: self.switch_page(5))
        tl.addWidget(tt)
        tl.addWidget(self.total_actions)
        tl.addStretch()
        tl.addWidget(go)

        cards.addWidget(total)
        lb.addLayout(cards)
        self.takeaways=QLabel("")
        self.takeaways.setVisible(False)
        lay.addWidget(pb)
        return w

    def build_table_page(self,title,kind):
        w=QWidget(); lay=QVBoxLayout(w); lay.setContentsMargins(0,0,0,0)
        p,pl=self.panel(title)

        if kind=="flight":
            filter_row=QHBoxLayout()
            filter_row.setContentsMargins(0,0,0,4)
            filter_row.setSpacing(8)

            status_lbl=QLabel("STATUS")
            status_lbl.setObjectName("filterLabel")
            self.flight_status_filter=QComboBox()
            self.flight_status_filter.addItems([
                "All",
                "NO CAPACITY",
                "LOW LF",
                "OK",
                "HIGH LF",
                "OVERBOOKED",
            ])
            self.flight_status_filter.setMinimumWidth(145)
            self.flight_status_filter.currentIndexChanged.connect(self.refresh)

            filter_row.addWidget(status_lbl)
            filter_row.addWidget(self.flight_status_filter)
            filter_row.addStretch()
            pl.addLayout(filter_row)

        model=DataFrameModel(); table=self.make_table(model); pl.addWidget(table)
        setattr(self,f"{kind}_model",model)
        setattr(self,f"{kind}_table",table)

        if kind=="flight":
            table.clicked.connect(self.open_flight_detail_from_table)
            table.setContextMenuPolicy(Qt.CustomContextMenu)
            table.customContextMenuRequested.connect(self.open_flight_capacity_menu)
        elif kind=="agent":
            table.doubleClicked.connect(self.open_agent_detail_from_table)
        elif kind=="dest":
            table.doubleClicked.connect(self.open_destination_detail_from_table)

        lay.addWidget(p)
        return w

    def build_revenue_page(self):
        w=QWidget(); lay=QVBoxLayout(w)
        p,pl=self.panel("Revenue & Pricing Intelligence")
        self.rev_label=QLabel("Selected-period revenue and unit revenue analytics will appear here.")
        self.rev_label.setStyleSheet("font-size:13px;color:#475569;")
        pl.addWidget(self.rev_label); pl.addStretch(); lay.addWidget(p)
        return w

    def make_table(self,model):
        t=QTableView(); t.setModel(model); t.setAlternatingRowColors(True)
        t.setSelectionBehavior(QAbstractItemView.SelectRows); t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        t.verticalHeader().setDefaultSectionSize(28)
        t.horizontalHeader().setMinimumHeight(30)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        t.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        t.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        return t

    def switch_page(self,idx):
        self.pages.setCurrentIndex(idx)
        for i,b in enumerate(self.nav_buttons):
            b.setObjectName("navActive" if i==idx else "nav")
            b.style().unpolish(b); b.style().polish(b)

    def update_period_controls(self):
        period=self.period_combo.currentText()
        is_weekly=(period=="Weekly")
        is_monthly=(period=="Monthly")
        self.week_combo.setEnabled(is_weekly)
        self.month_combo.setEnabled(is_monthly)
        self.week_combo.setToolTip("Select ISO week" if is_weekly else "Week disabled in Monthly/Yearly view")
        self.month_combo.setToolTip("Select month" if is_monthly else "Month disabled in Weekly/Yearly view")

    def set_view_segment(self, name):
        for n,b in self.view_buttons.items():
            b.setChecked(n == name)
        self.view_combo.setCurrentText(name)
        self.refresh()

    def clear_drilldown(self):
        self.source_filter = None
        self.commodity_filter = None
        self.agent_combo.blockSignals(True)
        self.dest_combo.blockSignals(True)
        self.agent_combo.setCurrentText("All")
        self.dest_combo.setCurrentText("All")
        self.agent_combo.blockSignals(False)
        self.dest_combo.blockSignals(False)
        self.clear_btn.setVisible(False)
        self.refresh()

    def reset_filters(self):
        if self.week_combo.count(): self.week_combo.setCurrentIndex(self.week_combo.count()-1)
        if self.year_combo.count(): self.year_combo.setCurrentIndex(self.year_combo.count()-1)
        self.source_filter=None; self.commodity_filter=None; self.clear_btn.setVisible(False); self.set_view_segment("All"); self.origin_combo.setCurrentText("All")
        self.dest_combo.setCurrentText("All"); self.agent_combo.setCurrentText("All")

        self.month_combo.setCurrentIndex(7)
        self.period_combo.setCurrentText("Weekly")

    def export_current_view(self):
        if self.data is None:
            QMessageBox.information(self, "Export", "Import a Booking List first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Dashboard Data", "CargoSalesDashboard_Export.xlsx",
            "Excel files (*.xlsx)"
        )
        if not path:
            return
        try:
            period = self.period_combo.currentText()
            year = int(self.year_combo.currentText())
            week = int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
            month = self.month_combo.currentIndex()+1
            view = self.view_combo.currentText()
            awbs, flights = filter_period(self.data, period, year, week=week, month=month, view=view)
            awbs, flights = self._apply_extra_filters(awbs, flights)
            with pd.ExcelWriter(path, engine="openpyxl") as writer:
                flights.to_excel(writer, sheet_name="Flight Performance", index=False)
                agent_performance(awbs).to_excel(writer, sheet_name="Agents", index=False)
                destination_performance(awbs).to_excel(writer, sheet_name="Destinations", index=False)
                awbs.to_excel(writer, sheet_name="AWB Data", index=False)
            QMessageBox.information(self, "Export", "Export completed.")
        except Exception as e:
            QMessageBox.critical(self, "Export error", str(e))

    def _capacity_override_path(self):
        # Cross-platform persistent storage.
        # Windows: %APPDATA%\CargoSalesControlTower
        # macOS/Linux fallback: user home application data directory.
        if sys.platform.startswith("win"):
            root = Path(os.environ.get("APPDATA", str(Path.home())))
            base = root / "CargoSalesControlTower"
        elif sys.platform == "darwin":
            base = Path.home() / "Library" / "Application Support" / "CargoSalesControlTower"
        else:
            base = Path.home() / ".local" / "share" / "CargoSalesControlTower"
        base.mkdir(parents=True, exist_ok=True)
        return base / "capacity_overrides.json"

    def _capacity_override_key(self, flight_date, flight, sector):
        dt=pd.Timestamp(flight_date).normalize()
        return f"{dt.strftime('%Y-%m-%d')}|{str(flight).strip()}|{str(sector).strip()}"

    def _load_capacity_overrides(self):
        path=self._capacity_override_path()
        if not path.exists():
            return {}
        try:
            raw=json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw,dict):
                return {}
            clean={}
            for key,value in raw.items():
                try:
                    clean[str(key)]=float(value)
                except Exception:
                    continue
            return clean
        except Exception:
            return {}

    def _save_capacity_overrides(self):
        path=self._capacity_override_path()
        tmp=path.with_suffix(".tmp")
        payload={k:float(v) for k,v in sorted(self.capacity_overrides.items())}
        tmp.write_text(json.dumps(payload,indent=2,sort_keys=True),encoding="utf-8")
        tmp.replace(path)

    def _flight_status_for_capacity(self, lf, capacity):
        if capacity <= 0 or pd.isna(lf):
            return "NO CAPACITY"
        if lf > 1:
            return "OVERBOOKED"
        if lf >= .90:
            return "HIGH LF"
        if lf < .60:
            return "LOW LF"
        return "OK"

    def _recalculate_flight_rows(self, mask):
        if self.data is None or self.data.flights is None or self.data.flights.empty:
            return
        df=self.data.flights
        for ridx in df.index[mask]:
            cap=float(df.at[ridx,"Capacity KG"] or 0)
            try:
                booked=float(df.at[ridx,"Booked CW KG"] or 0)
            except Exception:
                booked=0.0
            lf=(booked/cap) if cap>0 else None
            df.at[ridx,"LF %"]=lf
            df.at[ridx,"Gap KG"]=cap-booked
            df.at[ridx,"Status"]=self._flight_status_for_capacity(lf,cap)

    def _apply_capacity_overrides(self):
        if self.data is None or self.data.flights is None or self.data.flights.empty:
            return
        df=self.data.flights
        if "Capacity Source" not in df.columns:
            df["Capacity Source"]="MASTER"
        else:
            df["Capacity Source"]="MASTER"

        dates=pd.to_datetime(df["Flight Date"],errors="coerce")
        for ridx in df.index:
            dt=dates.loc[ridx]
            if pd.isna(dt):
                continue
            key=self._capacity_override_key(dt,df.at[ridx,"Flight"],df.at[ridx,"Sector"])
            if key in self.capacity_overrides:
                df.at[ridx,"Capacity KG"]=float(self.capacity_overrides[key])
                df.at[ridx,"Capacity Source"]="MANUAL"

        self._recalculate_flight_rows(pd.Series(True,index=df.index))

    def _master_capacity_for_row(self, row):
        return float(_capacity_for(
            row.get("Flight Date"),
            str(row.get("Flight","")),
            str(row.get("Sector","")),
            str(row.get("Flight Type","")),
        ))

    def import_file(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Import Booking Lists", "", "Excel files (*.xlsx *.xls)")
        if not paths:
            return
        try:
            self.data = load_comis_booking_lists(paths)
            self._apply_capacity_overrides()
            iq = self.data.import_quality or {}
            self._last_import_quality = iq
            years, weeks = available_periods(self.data)
            self.year_combo.blockSignals(True); self.week_combo.blockSignals(True)
            self.year_combo.clear(); self.week_combo.clear()
            for y in years: self.year_combo.addItem(str(y))
            for w in weeks: self.week_combo.addItem(str(w))
            self.year_combo.blockSignals(False); self.week_combo.blockSignals(False)
            self.dest_combo.blockSignals(True); self.agent_combo.blockSignals(True)
            self.dest_combo.clear(); self.agent_combo.clear(); self.dest_combo.addItem("All"); self.agent_combo.addItem("All")
            if not self.data.awbs.empty:
                for d in sorted(self.data.awbs["Destination"].dropna().astype(str).unique()):
                    if d and d != "nan": self.dest_combo.addItem(d)
                for a in sorted(self.data.awbs["Agent"].dropna().astype(str).unique()):
                    if a and a != "nan": self.agent_combo.addItem(a)
            self.dest_combo.blockSignals(False); self.agent_combo.blockSignals(False)
            if self.week_combo.count(): self.week_combo.setCurrentIndex(self.week_combo.count()-1)
            if self.year_combo.count(): self.year_combo.setCurrentIndex(self.year_combo.count()-1)
            stamp = datetime.now().strftime("%d %b %Y  %H:%M")
            fc=int(iq.get('files',len(paths))); ma=int(iq.get('master_awbs',len(self.data.awbs))); dr=int(iq.get('total_duplicates_removed',0)); dc=float(iq.get('total_duplicate_cw_removed',0)); mc=float(iq.get('master_cw',0))
            self.last_update_value.setText(stamp)
            self.last_update_file.setText(f"{fc} files  •  {ma:,} master AWBs")
            self.header_status.setText(f"Last Update: {stamp}  •  {fc} files  •  {ma:,} AWBs")
            self.refresh()
            self.import_summary.setText(
                f"{fc} files imported\n"
                f"Master unique AWBs: {ma:,}\n"
                f"Duplicates removed: {dr:,}\n"
                f"Duplicate CW removed: {dc:,.0f} kg\n"
                f"Master CW: {mc/1000:,.1f} ton\n\n"
                "Same AWB in multiple files: later selected file retained."
            )
        except Exception as e:
            QMessageBox.critical(self, "Import error", str(e))

    def _apply_extra_filters(self,awbs,flights):
        if awbs.empty: return awbs,flights
        o=self.origin_combo.currentText()
        d=self.dest_combo.currentText()
        a=self.agent_combo.currentText()
        if o and o!="All": awbs=awbs[awbs["Origin"]==o].copy()
        if d and d!="All": awbs=awbs[awbs["Destination"]==d].copy()
        if a and a!="All": awbs=awbs[awbs["Agent"]==a].copy()
        if self.source_filter:
            if self.source_filter == "OnlineSales":
                awbs = awbs[awbs["Source"].str.lower()=="onlinesales"].copy()
            else:
                awbs = awbs[awbs["Source"].str.lower()!="onlinesales"].copy()
        if self.commodity_filter and "Cargo Category" in awbs.columns:
            awbs = awbs[awbs["Cargo Category"]==self.commodity_filter].copy()
        if flights.empty or awbs.empty:
            return awbs, flights.iloc[0:0]
        keys=set(zip(awbs["Flight Date"],awbs["Primary Flight"]))
        flights=flights[flights.apply(lambda r:(r["Flight Date"],r["Flight"]) in keys,axis=1)].copy()
        return awbs,flights

    def on_source_slice_clicked(self, name):
        new_filter = "OnlineSales" if name=="OnlineSales" else "Other"
        if self.source_filter == new_filter:
            self.source_filter = None
            self.clear_btn.setVisible(False)
        else:
            self.source_filter = new_filter
            self.clear_btn.setVisible(True)
        self.refresh()

    def on_opportunity_clicked(self, index):
        row=self.opportunity_model.row_dict(index.row())
        dest=row.get("Destination")
        if not dest:
            return
        if self.dest_combo.currentText()==str(dest):
            self.dest_combo.setCurrentText("All")
            self.clear_btn.setVisible(False)
        else:
            self.dest_combo.setCurrentText(str(dest))
            self.clear_btn.setVisible(True)
        self.refresh()

    def on_opportunity_double_clicked(self, index):
        row=self.opportunity_model.row_dict(index.row())
        dest=row.get("Destination")
        if not dest or self.data is None:
            return
        current=self.data.awbs[self.data.awbs["Destination"]==dest].copy()
        period=self.period_combo.currentText()
        year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1
        view=self.view_combo.currentText()
        prev=self._previous_period_awbs(period,year,week,month,view)
        prev=prev[prev["Destination"]==dest].copy()
        IntelligenceDialog("Destination Intelligence", str(dest), current, prev, self).exec()

    def on_agent_overview_clicked(self, index):
        row = self.agent_over_model.row_dict(index.row())
        agent = row.get("Agent")
        if agent:
            if self.agent_combo.currentText() == str(agent):
                self.agent_combo.setCurrentText("All")
                self.clear_btn.setVisible(False)
            else:
                self.agent_combo.setCurrentText(str(agent))
                self.clear_btn.setVisible(True)
            self.refresh()

    def on_destination_overview_clicked(self, index):
        row = self.dest_over_model.row_dict(index.row())
        dest = row.get("Destination")
        if dest:
            if self.dest_combo.currentText() == str(dest):
                self.dest_combo.setCurrentText("All")
                self.clear_btn.setVisible(False)
            else:
                self.dest_combo.setCurrentText(str(dest))
                self.clear_btn.setVisible(True)
            self.refresh()

    def _current_context_awbs(self):
        period=self.period_combo.currentText()
        year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1
        view=self.view_combo.currentText()
        a,f=filter_period(self.data,period,year,week=week,month=month,view=view)
        a,f=self._apply_extra_filters(a,f)
        prev=self._previous_period_awbs(period,year,week,month,view)
        return a,prev

    def open_flight_capacity_menu(self, pos):
        """Persistent right-click capacity edit/reset for Flight Performance."""
        if self.data is None:
            return
        index=self.flight_table.indexAt(pos)
        if not index.isValid():
            return
        try:
            col_name=str(self.flight_model.df.columns[index.column()])
        except Exception:
            return
        if col_name != "Capacity KG":
            return

        row=self.flight_model.row_dict(index.row())
        if not row:
            return

        flight=str(row.get("Flight",""))
        sector=str(row.get("Sector",""))
        fdate=pd.Timestamp(row.get("Flight Date")).normalize()
        key=self._capacity_override_key(fdate,flight,sector)

        menu=QMenu(self.flight_table)
        edit_action=menu.addAction("Edit Capacity…")
        reset_action=menu.addAction("Reset to Master Capacity")
        reset_action.setEnabled(key in self.capacity_overrides)
        selected=menu.exec(self.flight_table.viewport().mapToGlobal(pos))
        if selected is None:
            return

        df=self.data.flights
        if df is None or df.empty:
            return

        dates=pd.to_datetime(df["Flight Date"],errors="coerce").dt.normalize()
        mask=dates.eq(fdate) & df["Flight"].astype(str).eq(flight)
        if "Sector" in df.columns and sector:
            mask &= df["Sector"].astype(str).eq(sector)

        if not mask.any():
            QMessageBox.warning(self,"Capacity Edit","Matching flight could not be found in the master data.")
            return

        if selected == reset_action:
            master_capacity=self._master_capacity_for_row(row)
            self.capacity_overrides.pop(key,None)
            self._save_capacity_overrides()
            self.data.flights.loc[mask,"Capacity KG"]=float(master_capacity)
            if "Capacity Source" not in self.data.flights.columns:
                self.data.flights["Capacity Source"]="MASTER"
            self.data.flights.loc[mask,"Capacity Source"]="MASTER"
            self._recalculate_flight_rows(mask)
            self.refresh()
            return

        if selected != edit_action:
            return

        try:
            current=float(row.get("Capacity KG",0) or 0)
        except Exception:
            current=0.0

        new_capacity,ok=QInputDialog.getDouble(
            self,
            "Edit Flight Capacity",
            f"{flight} • {fdate.strftime('%d %b %Y')}\n"
            "Capacity KG:",
            current,
            0.0,
            500000.0,
            1
        )
        if not ok:
            return

        # Save first: the override survives even if the app is closed immediately.
        self.capacity_overrides[key]=float(new_capacity)
        self._save_capacity_overrides()

        self.data.flights.loc[mask,"Capacity KG"]=float(new_capacity)
        if "Capacity Source" not in self.data.flights.columns:
            self.data.flights["Capacity Source"]="MASTER"
        self.data.flights.loc[mask,"Capacity Source"]="MANUAL"
        self._recalculate_flight_rows(mask)

        # Refresh all dependent KPIs, LF, gap, status, charts and alerts.
        self.refresh()

    def open_flight_detail_from_table(self, index):
        if self.data is None:
            return
        row = self.flight_model.row_dict(index.row())
        if not row:
            return

        flight = str(row.get("Flight",""))
        flight_date = row.get("Flight Date")
        if not flight or pd.isna(flight_date):
            return
        flight_date = pd.Timestamp(flight_date)

        # Get current dashboard context first.
        period=self.period_combo.currentText()
        year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1
        view=self.view_combo.currentText()
        awbs, flights = filter_period(self.data,period,year,week=week,month=month,view=view)
        awbs, flights = self._apply_extra_filters(awbs,flights)

        # Filter AWBs tied to the selected primary flight/date.
        fa = awbs[
            (awbs["Primary Flight"].astype(str)==flight) &
            (pd.to_datetime(awbs["Flight Date"],errors="coerce")==flight_date)
        ].copy()

        FlightDetailDialog(row, fa, self).exec()

    def open_agent_detail_from_table(self, index):
        row = self.agent_model.row_dict(index.row())
        agent = row.get("Agent")
        if not agent or self.data is None: return
        current,prev=self._current_context_awbs()
        # remove current agent filter context then refilter by selected entity
        current = self.data.awbs[self.data.awbs["Agent"]==agent].copy()
        # previous period context with same agent
        period=self.period_combo.currentText(); year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1; view=self.view_combo.currentText()
        pa=self._previous_period_awbs(period,year,week,month,view)
        pa=pa[pa["Agent"]==agent].copy()
        IntelligenceDialog("Agent Intelligence", str(agent), current, pa, self).exec()

    def open_destination_detail_from_table(self, index):
        row = self.dest_model.row_dict(index.row())
        dest = row.get("Destination")
        if not dest or self.data is None: return
        current = self.data.awbs[self.data.awbs["Destination"]==dest].copy()
        period=self.period_combo.currentText(); year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1; view=self.view_combo.currentText()
        pa=self._previous_period_awbs(period,year,week,month,view)
        pa=pa[pa["Destination"]==dest].copy()
        IntelligenceDialog("Destination Intelligence", str(dest), current, pa, self).exec()

    def _previous_period_awbs(self, period, year, week, month, view):
        if period == "Weekly":
            pw = week - 1
            py = year
            if pw < 1:
                py -= 1
                pw = 52
            a, f = filter_period(self.data, "Weekly", py, week=pw, view=view)
        elif period == "Monthly":
            pm = month - 1
            py = year
            if pm < 1:
                pm = 12
                py -= 1
            a, f = filter_period(self.data, "Monthly", py, month=pm, view=view)
        else:
            a, f = filter_period(self.data, "Yearly", year-1, view=view)
        a, f = self._apply_extra_filters(a, f)
        return a

    def _agent_comparison(self, current_awbs, previous_awbs):
        cur = agent_performance(current_awbs)
        prev = agent_performance(previous_awbs)
        if cur.empty:
            return pd.DataFrame(columns=["Agent","CW KG","Revenue USD","UR USD/kg","AWBs","CW Change"])
        prev_map = prev.set_index("Agent")["CW KG"].to_dict() if not prev.empty else {}
        cur["CW Change"] = cur.apply(
            lambda r: ((r["CW KG"]/prev_map.get(r["Agent"], 0))-1) if prev_map.get(r["Agent"],0) else None,
            axis=1
        )
        return cur

    def _destination_comparison(self, current_awbs, previous_awbs):
        cur = destination_performance(current_awbs)
        prev = destination_performance(previous_awbs)
        if cur.empty:
            return pd.DataFrame(columns=["Destination","CW KG","Revenue USD","UR USD/kg","AWBs","CW Change"])
        prev_map = prev.set_index("Destination")["CW KG"].to_dict() if not prev.empty else {}
        cur["CW Change"] = cur.apply(
            lambda r: ((r["CW KG"]/prev_map.get(r["Destination"], 0))-1) if prev_map.get(r["Destination"],0) else None,
            axis=1
        )
        return cur

    def previous_stats(self, period, year, week, month, view):
        if period == "Weekly":
            pw = week - 1
            py = year
            if pw < 1:
                py -= 1
                pw = 52
            a,f = filter_period(self.data, "Weekly", py, week=pw, view=view)
        elif period == "Monthly":
            pm = month - 1
            py = year
            if pm < 1:
                pm = 12
                py -= 1
            a,f = filter_period(self.data, "Monthly", py, month=pm, view=view)
        else:
            a,f = filter_period(self.data, "Yearly", year-1, view=view)

        a,f = self._apply_extra_filters(a,f)
        return kpis(a,f)

    def refresh(self):
        if self.data is None or not self.week_combo.currentText() or not self.year_combo.currentText():
            return
        self.update_period_controls()
        active_drill = (self.source_filter is not None or
                        self.commodity_filter is not None or
                        self.agent_combo.currentText() not in ("","All") or
                        self.dest_combo.currentText() not in ("","All"))
        self.clear_btn.setVisible(active_drill)
        period=self.period_combo.currentText()
        year=int(self.year_combo.currentText())
        week=int(self.week_combo.currentText()) if self.week_combo.currentText() else 1
        month=self.month_combo.currentIndex()+1
        view=self.view_combo.currentText()

        awbs,flights=filter_period(self.data,period,year,week=week,month=month,view=view)
        awbs,flights=self._apply_extra_filters(awbs,flights)
        stats=kpis(awbs,flights); prev=self.previous_stats(period,year,week,month,view)

        def delta(c,p): return None if p in (0,None) else c/p-1

        values={
            "Booked CW":f'{stats["Booked CW"]:,.0f}',
            "Revenue":f'{stats["Revenue"]:,.0f}',
            "Overall UR":f'{stats["Overall UR"]:.2f}',
            "Freighter LF":f'{stats["Freighter LF"]:.1%}',
            "Pax LF":f'{stats["Pax LF"]:.1%}',
            "Freighter UR":f'{stats["Freighter UR"]:.2f}',
            "Pax UR":f'{stats["Pax UR"]:.2f}',
            "Online Share":f'{stats["Online Share"]:.1%}',
            "Pharma Share":f'{stats["Pharma Share"]:.1%}',
            "Pharma Tonnage":f'{stats["Pharma Tonnage"]:,.1f}',
            "General Cargo Share":f'{stats["General Cargo Share"]:.1%}',
            "AWBs":f'{stats["AWBs"]:,}',
        }
        for k,v in values.items(): self.cards[k].value.setText(v)
        delta_label = "WoW" if period=="Weekly" else ("MoM" if period=="Monthly" else "YoY")
        self.agent_over_title.setText(f"TOP AGENTS — CW CHANGE ({delta_label})")
        self.dest_over_title.setText(f"TOP DESTINATIONS — CW CHANGE ({delta_label})")
        for k in self.cards:
            self.cards[k].set_delta(delta(stats[k],prev[k]) if k in stats and k in prev else None, delta_label)

        prev_awbs = self._previous_period_awbs(period,year,week,month,view)
        agents = self._agent_comparison(awbs, prev_awbs)
        dests = self._destination_comparison(awbs, prev_awbs)
        actions=recommended_actions(flights,agents)

        agent_cols=["Agent","CW KG","Revenue USD","UR USD/kg","AWBs","CW Change"]
        dest_cols=["Destination","CW KG","Revenue USD","UR USD/kg","AWBs","CW Change"]
        self.agent_over_model.set_df(agents.head(5)[agent_cols] if not agents.empty else pd.DataFrame(columns=agent_cols))
        self.dest_over_model.set_df(dests.head(5)[dest_cols] if not dests.empty else pd.DataFrame(columns=dest_cols))

        # Top Sales Opportunities — commercial attractiveness ranking.
        opp_cols=["Destination","CW KG","Revenue USD","UR USD/kg","CW Change","Opportunity Score"]
        if not dests.empty:
            opp=dests.copy()
            max_cw=max(float(pd.to_numeric(opp["CW KG"],errors="coerce").fillna(0).max()),1.0)
            max_rev=max(float(pd.to_numeric(opp["Revenue USD"],errors="coerce").fillna(0).max()),1.0)
            max_ur=max(float(pd.to_numeric(opp["UR USD/kg"],errors="coerce").fillna(0).max()),1.0)

            def _opp_score(r):
                cw=max(float(r.get("CW KG",0) or 0),0.0)
                rev=max(float(r.get("Revenue USD",0) or 0),0.0)
                ur=max(float(r.get("UR USD/kg",0) or 0),0.0)
                ch=r.get("CW Change")
                try:
                    ch=float(ch)
                except Exception:
                    ch=0.0

                volume_score=min(cw/max_cw,1.0)*35.0
                revenue_score=min(rev/max_rev,1.0)*25.0
                ur_score=min(ur/max_ur,1.0)*25.0
                momentum_score=(min(ch,1.0)*15.0 if ch>=0 else min(abs(ch),1.0)*7.5)
                return round(min(100.0,volume_score+revenue_score+ur_score+momentum_score))

            opp["Opportunity Score"]=opp.apply(_opp_score,axis=1)
            opp=opp.sort_values(
                ["Opportunity Score","CW KG","Revenue USD","UR USD/kg"],
                ascending=[False,False,False,False]
            ).head(5)
            self.opportunity_model.set_df(opp[opp_cols])
        else:
            self.opportunity_model.set_df(pd.DataFrame(columns=opp_cols))

        self.agent_model.set_df(agents.head(100))
        self.dest_model.set_df(dests.head(100))
        self.actions_model.set_df(pd.DataFrame(actions,columns=["Category","Priority","Action"]))
        self.total_actions.setText(str(len(actions)))
        # Dynamic action cards — target metrics
        open_capacity = float(flights["Gap KG"].clip(lower=0).sum()) if not flights.empty else 0
        low_ur_agents = agents[agents["UR USD/kg"] < stats["Overall UR"]] if not agents.empty and stats["Overall UR"] else agents.iloc[0:0]

        declining_dests = dests.dropna(subset=["CW Change"]) if not dests.empty and "CW Change" in dests.columns else dests.iloc[0:0]
        declining_dests = declining_dests[declining_dests["CW Change"] < -0.10] if not declining_dests.empty else declining_dests

        rising_dests = dests.dropna(subset=["CW Change"]) if not dests.empty and "CW Change" in dests.columns else dests.iloc[0:0]
        rising_dests = rising_dests[rising_dests["CW Change"] > 0.15] if not rising_dests.empty else rising_dests

        action_metrics = [
            (f"{open_capacity/1000:.1f}", "TON", "Available low-LF capacity. Prioritize weak flights and open-space sales."),
            (f"{len(low_ur_agents)}", "AGENTS", "Below selected-period UR. Review pricing, mix and low-yield bookings."),
            (f"{len(rising_dests)}", "DESTINATIONS", "Growing >15% vs previous period. Target for incremental volume."),
            (f"{len(declining_dests)}", "DESTINATIONS", "Down >10% vs previous period. Review and re-engage historical volume owners."),
        ]

        for card,vals in zip(self.action_cards,action_metrics):
            metric_txt,unit_txt,body_txt=vals
            card["metric"].setText(metric_txt)
            card["unit"].setText(unit_txt)
            card["body"].setText(body_txt)


        flight_cols=["Flight Date","DOW","Flight","Flight Type","Sector","Capacity KG","Capacity Source","Booked CW KG","LF %","Revenue USD","UR USD/kg","AWBs","Gap KG","Status"]

        # Flight Performance page table filter.
        # This does not alter Executive Overview KPIs/charts; it only filters the flight list.
        flight_table_df=flights.copy()
        status_filter="All"
        if hasattr(self,"flight_status_filter"):
            status_filter=self.flight_status_filter.currentText() or "All"
        if status_filter!="All" and not flight_table_df.empty and "Status" in flight_table_df.columns:
            flight_table_df=flight_table_df[flight_table_df["Status"].astype(str)==status_filter].copy()

        self.flight_model.set_df(
            flight_table_df[flight_cols]
            if not flight_table_df.empty
            else pd.DataFrame(columns=flight_cols)
        )

        self.build_trend_charts(period,year,week,month,view)

        insight_lines=[]
        # agent movers
        if not agents.empty and "CW Change" in agents.columns:
            dec = agents.dropna(subset=["CW Change"]).sort_values("CW Change").head(2)
            inc = agents.dropna(subset=["CW Change"]).sort_values("CW Change",ascending=False).head(2)
            for _,r in dec.iterrows():
                if r["CW Change"] < -0.10:
                    insight_lines.append(f"🔴 {str(r['Agent'])[:26]}: CW down {abs(r['CW Change']):.1%}. Re-engage and review lost destinations.")
            for _,r in inc.iterrows():
                if r["CW Change"] > 0.15:
                    insight_lines.append(f"🟢 {str(r['Agent'])[:26]}: CW up {r['CW Change']:.1%}. Secure repeat volume and protect pricing.")
        if not dests.empty and "CW Change" in dests.columns:
            decd=dests.dropna(subset=["CW Change"]).sort_values("CW Change").head(2)
            for _,r in decd.iterrows():
                if r["CW Change"] < -0.10:
                    insight_lines.append(f"🔴 {r['Destination']}: CW down {abs(r['CW Change']):.1%}. Check agents that previously supported this lane.")
        if not flights.empty:
            low=flights[(flights["Capacity KG"]>0)&(flights["LF %"]<0.60)].sort_values("LF %").head(2)
            for _,r in low.iterrows():
                insight_lines.append(f"🟠 {r['Flight']} {pd.Timestamp(r['Flight Date']).strftime('%d %b')}: LF {r['LF %']:.0%}, {max(r['Gap KG'],0):,.0f} kg open capacity.")
        if not insight_lines:
            insight_lines=["🟢 No critical decline detected for the selected filters. Maintain current sales focus."]
        self.update_executive_insights(insight_lines[:6])

        action_txt = "\n".join([f"• {x[2]}" for x in actions[:4]]) if actions else "No urgent actions for the selected filters."
        self.takeaways.setText(action_txt)

        self.rev_label.setText(
            f"Revenue ${stats['Revenue']:,.0f}  •  Overall UR ${stats['Overall UR']:.2f}/kg  •  "
            f"Freighter UR ${stats['Freighter UR']:.2f}/kg  •  Pax UR ${stats['Pax UR']:.2f}/kg"
        )

    def update_executive_insights(self, lines):
        # Clear previous alert cards.
        while self.insight_layout.count():
            item=self.insight_layout.takeAt(0)
            w=item.widget()
            if w is not None:
                w.deleteLater()

        if not lines:
            lines=["No material alert for the selected filters."]

        for raw in lines[:8]:
            # Determine semantic severity from existing signal text.
            if raw.startswith("🔴"):
                tone="#FF3B43"; icon="!"
            elif raw.startswith("🟠") or raw.startswith("🟡"):
                tone="#FF9D19"; icon="!"
            elif raw.startswith("🟢"):
                tone="#39D353"; icon="✓"
            else:
                tone="#3FA7FF"; icon="i"

            clean=raw
            for prefix in ("🔴 ","🟠 ","🟡 ","🟢 ","🔵 "):
                clean=clean.replace(prefix,"",1) if clean.startswith(prefix) else clean

            card=QFrame()
            card.setStyleSheet(
                "QFrame{background:#08263E;border:1px solid #173E58;border-radius:7px;}"
            )
            row=QHBoxLayout(card)
            row.setContentsMargins(7,5,7,5)
            row.setSpacing(7)
            badge=QLabel(icon)
            badge.setAlignment(Qt.AlignCenter)
            badge.setFixedSize(20,20)
            badge.setStyleSheet(
                f"background:{tone};color:white;border-radius:10px;font-size:11px;font-weight:900;"
            )
            msg=QLabel(clean)
            msg.setWordWrap(True)
            msg.setStyleSheet("color:#E6EEF5;font-size:9px;background:transparent;border:0px;")
            row.addWidget(badge)
            row.addWidget(msg,1)
            self.insight_layout.addWidget(card)
        self.insight_layout.addStretch()

    def eventFilter(self, obj, event):
        cw=getattr(self,"cw_view",None)
        rev=getattr(self,"revenue_view",None)
        lf=getattr(self,"lf_view",None)
        chart_widgets=tuple(w for w in (cw,rev,lf) if w is not None)

        if obj in chart_widgets:
            if event.type()==QEvent.MouseMove:
                data=getattr(self,"_trend_hover_data",{}) or {}
                points=data.get("cw",[])
                if not points:
                    if hasattr(self,"_trend_tooltip"):
                        self._trend_tooltip.hide()
                    return super().eventFilter(obj,event)

                left=42.0
                right=max(left+1.0,float(obj.width())-12.0)
                x=float(event.position().x())

                if x < left-12 or x > right+12:
                    if hasattr(self,"_trend_tooltip"):
                        self._trend_tooltip.hide()
                    return super().eventFilter(obj,event)

                n=len(points)
                slot=(right-left)/max(n,1)
                idx=int((x-left)/slot) if slot>0 else 0
                idx=max(0,min(n-1,idx))
                label,st=points[idx]

                if obj is cw:
                    tip=f"{label}\nCW: {st['Booked CW']:,.0f} kg"
                elif obj is rev:
                    tip=f"{label}\nRevenue: ${st['Revenue']:,.0f}"
                else:
                    mode=data.get("view","All")
                    if mode=="Freighter":
                        tip=f"{label}\nFreighter LF: {st['Freighter LF']:.1%}\nTarget: 90%"
                    elif mode=="Pax":
                        tip=f"{label}\nPax LF: {st['Pax LF']:.1%}\nTarget: 50%"
                    else:
                        tip=(f"{label}\n"
                             f"Freighter LF: {st['Freighter LF']:.1%}  (Target 90%)\n"
                             f"Pax LF: {st['Pax LF']:.1%}  (Target 50%)")

                tt=getattr(self,"_trend_tooltip",None)
                if tt is not None:
                    tt.setText(tip)
                    tt.adjustSize()

                    try:
                        gp=event.globalPosition().toPoint()
                    except Exception:
                        gp=obj.mapToGlobal(event.position().toPoint())

                    # Offset from cursor so it never sits directly under the pointer.
                    pos=gp + QPoint(16,18)

                    # Keep tooltip on-screen as much as possible.
                    screen=QApplication.screenAt(gp)
                    if screen is not None:
                        geo=screen.availableGeometry()
                        if pos.x()+tt.width()>geo.right():
                            pos.setX(gp.x()-tt.width()-16)
                        if pos.y()+tt.height()>geo.bottom():
                            pos.setY(gp.y()-tt.height()-16)

                    tt.move(pos)
                    tt.show()
                    tt.raise_()
                return False

            if event.type()==QEvent.Leave:
                if hasattr(self,"_trend_tooltip"):
                    self._trend_tooltip.hide()

        return super().eventFilter(obj,event)

    def _chart_canvas(self, widget, min_w=190, min_h=140):
        # Render at Retina resolution but never force a canvas wider than its panel.
        # The previous 360px minimum caused the right side of charts to be cropped.
        ww=widget.width()
        wh=widget.height()
        logical_w=max(min_w, ww if ww>80 else min_w)
        logical_h=max(min_h, wh if wh>80 else min_h)
        dpr=2.0
        pm=QPixmap(int(logical_w*dpr), int(logical_h*dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(QColor("#061D31"))
        return pm

    def _draw_axes(self,p,rect,labels):
        p.setRenderHint(QPainter.Antialiasing,True)
        grid=QPen(QColor("#24445D")); grid.setWidth(1)
        p.setPen(grid)
        for i in range(5):
            y=rect.bottom()-rect.height()*i/4
            p.drawLine(QPointF(rect.left(),y),QPointF(rect.right(),y))
        p.setPen(QColor("#C7D3DE"))
        f=QFont(); f.setPointSize(7); p.setFont(f)
        n=len(labels)
        if n:
            for i,lab in enumerate(labels):
                x=rect.left()+(i+0.5)*rect.width()/n
                p.drawText(QRectF(x-30,rect.bottom()+4,60,18),Qt.AlignCenter,str(lab))

    def _render_cw_pixmap(self,points):
        pm=self._chart_canvas(self.cw_view,190,132); p=QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing,True)
        dpr=pm.devicePixelRatio(); lw=pm.width()/dpr; lh=pm.height()/dpr
        rect=QRectF(42,16,lw-54,lh-42)
        labels=[x[0] for x in points]
        vals=[float(st["Booked CW"]) for _,st in points]
        mx=max(vals+[1])

        # horizontal grid + Y labels
        p.setPen(QPen(QColor("#24445D"),1))
        for i in range(5):
            y=rect.bottom()-rect.height()*i/4
            p.drawLine(QPointF(rect.left(),y),QPointF(rect.right(),y))
            v=mx*i/4
            p.setPen(QColor("#B8C8D6"))
            f=QFont(); f.setPointSize(6); p.setFont(f)
            lbl=f"{v/1000:.0f}K" if v>=1000 else f"{v:.0f}"
            p.drawText(QRectF(0,y-8,40,16),Qt.AlignRight|Qt.AlignVCenter,lbl)
            p.setPen(QPen(QColor("#24445D"),1))

        n=max(1,len(vals)); slot=rect.width()/n; bw=min(28,slot*.52)
        xs=[]
        for i,v in enumerate(vals):
            x=rect.left()+(i+.5)*slot; xs.append(x)
            h=rect.height()*(v/mx)*.82 if mx else 0
            p.fillRect(QRectF(x-bw/2,rect.bottom()-h,bw,h),QColor("#1779D4"))
            p.setPen(QColor("#E7EEF5")); f=QFont(); f.setPointSize(7); f.setBold(True); p.setFont(f)
            txt=f"{v/1000:.0f}K" if v>=1000 else f"{v:.0f}"
            p.drawText(QRectF(x-24,rect.bottom()-h-16,48,13),Qt.AlignCenter,txt)

        p.setPen(QColor("#CBD7E1")); f=QFont(); f.setPointSize(6); p.setFont(f)
        for lab,x in zip(labels,xs):
            p.drawText(QRectF(x-25,rect.bottom()+3,50,16),Qt.AlignCenter,str(lab))
        p.end(); self.cw_view.setPixmap(pm)

    def _render_revenue_pixmap(self,points):
        pm=self._chart_canvas(self.revenue_view,190,132); p=QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing,True)
        dpr=pm.devicePixelRatio(); lw=pm.width()/dpr; lh=pm.height()/dpr
        rect=QRectF(42,16,lw-54,lh-42)
        labels=[x[0] for x in points]
        vals=[float(st["Revenue"]) for _,st in points]
        mx=max(vals+[1]); n=len(vals)

        p.setPen(QPen(QColor("#24445D"),1))
        for i in range(5):
            y=rect.bottom()-rect.height()*i/4
            p.drawLine(QPointF(rect.left(),y),QPointF(rect.right(),y))
            v=mx*i/4
            p.setPen(QColor("#B8C8D6")); f=QFont(); f.setPointSize(6); p.setFont(f)
            lbl=f"{v/1_000_000:.2f}M" if v>=1_000_000 else (f"{v/1000:.0f}K" if v>=1000 else f"{v:.0f}")
            p.drawText(QRectF(0,y-8,40,16),Qt.AlignRight|Qt.AlignVCenter,lbl)
            p.setPen(QPen(QColor("#24445D"),1))

        if n:
            xs=[rect.left()+(i+.5)*rect.width()/n for i in range(n)]
            ys=[rect.bottom()-rect.height()*(v/mx)*.78 for v in vals]

            area=QPainterPath(); area.moveTo(xs[0],rect.bottom())
            for x,y in zip(xs,ys): area.lineTo(x,y)
            area.lineTo(xs[-1],rect.bottom()); area.closeSubpath()
            p.fillPath(area,QColor(46,227,125,38))

            line=QPainterPath(); line.moveTo(xs[0],ys[0])
            for x,y in zip(xs[1:],ys[1:]): line.lineTo(x,y)
            p.setPen(QPen(QColor("#38E37D"),3)); p.drawPath(line)
            p.setBrush(QColor("#38E37D")); p.setPen(QPen(QColor("#E9FFF1"),1))
            for x,y in zip(xs,ys): p.drawEllipse(QPointF(x,y),3.2,3.2)

            # Small clean value labels, offset from the line.
            f=QFont(); f.setPointSize(5); f.setBold(True); p.setFont(f)
            for idx,(x,y,v) in enumerate(zip(xs,ys,vals)):
                txt=f"{v/1_000_000:.2f}M" if v>=1_000_000 else (f"{v/1000:.0f}K" if v>=1000 else f"{v:.0f}")

                # Alternate above/below so neighbouring values do not collide.
                if idx % 2 == 0:
                    yy=y-16
                    if yy < rect.top()+1:
                        yy=y+6
                else:
                    yy=y+5
                    if yy > rect.bottom()-12:
                        yy=y-16

                yy=max(rect.top()+1,min(rect.bottom()-12,yy))
                p.setPen(QColor("#EAF8EF"))
                p.drawText(QRectF(x-22,yy,44,11),Qt.AlignCenter,txt)

            p.setPen(QColor("#CBD7E1")); f=QFont(); f.setPointSize(6); p.setFont(f)
            for lab,x in zip(labels,xs):
                p.drawText(QRectF(x-25,rect.bottom()+3,50,16),Qt.AlignCenter,str(lab))
        p.end(); self.revenue_view.setPixmap(pm)

    def _render_lf_pixmap(self,points,view):
        pm=self._chart_canvas(self.lf_view,190,132)
        p=QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing,True)

        dpr=pm.devicePixelRatio()
        lw=pm.width()/dpr
        lh=pm.height()/dpr
        rect=QRectF(42,16,lw-54,lh-42)
        labels=[x[0] for x in points]
        n=len(points)

        # Grid + axis
        p.setPen(QPen(QColor("#24445D"),1))
        for pct in (0,25,50,75,100):
            y=rect.bottom()-rect.height()*(pct/100)
            p.drawLine(QPointF(rect.left(),y),QPointF(rect.right(),y))
            p.setPen(QColor("#B8C8D6"))
            f=QFont(); f.setPointSize(6); p.setFont(f)
            p.drawText(QRectF(0,y-8,38,16),Qt.AlignRight|Qt.AlignVCenter,f"{pct}%")
            p.setPen(QPen(QColor("#24445D"),1))

        # Separate LF targets by aircraft type.
        f=QFont(); f.setPointSize(5); f.setBold(True); p.setFont(f)
        if view in ("All","Freighter"):
            fy=rect.bottom()-rect.height()*0.90
            p.setPen(QPen(QColor("#4AA8FF"),1,Qt.DashLine))
            p.drawLine(QPointF(rect.left(),fy),QPointF(rect.right(),fy))
            p.setPen(QColor("#7EC4FF"))
            p.drawText(QRectF(rect.right()-68,fy-11,66,10),Qt.AlignRight|Qt.AlignVCenter,"F TARGET 90%")
        if view in ("All","Pax"):
            py=rect.bottom()-rect.height()*0.50
            p.setPen(QPen(QColor("#FF7076"),1,Qt.DashLine))
            p.drawLine(QPointF(rect.left(),py),QPointF(rect.right(),py))
            p.setPen(QColor("#FF9A9F"))
            p.drawText(QRectF(rect.right()-68,py+2,66,10),Qt.AlignRight|Qt.AlignVCenter,"P TARGET 50%")

        if n:
            xs=[rect.left()+(i+.5)*rect.width()/n for i in range(n)]

            def draw_line(key,color):
                vals=[max(0,min(1,float(st[key]))) for _,st in points]
                ys=[rect.bottom()-rect.height()*v for v in vals]

                path=QPainterPath()
                path.moveTo(xs[0],ys[0])
                for x,y in zip(xs[1:],ys[1:]):
                    path.lineTo(x,y)

                p.setPen(QPen(QColor(color),2.6))
                p.drawPath(path)
                p.setBrush(QColor(color))
                p.setPen(QPen(QColor("#FFFFFF"),1))
                for x,y in zip(xs,ys):
                    p.drawEllipse(QPointF(x,y),3.3,3.3)

                return vals,ys

            freighter_vals=freighter_ys=None
            pax_vals=pax_ys=None

            if view=="Freighter":
                freighter_vals,freighter_ys=draw_line("Freighter LF","#2D9CFF")
            elif view=="Pax":
                pax_vals,pax_ys=draw_line("Pax LF","#FF4A52")
            else:
                freighter_vals,freighter_ys=draw_line("Freighter LF","#2D9CFF")
                pax_vals,pax_ys=draw_line("Pax LF","#FF4A52")

            # Latest values only — clear executive view.
            f=QFont(); f.setPointSize(6); f.setBold(True); p.setFont(f)

            if freighter_vals:
                x=xs[-1]; y=freighter_ys[-1]
                yy=max(rect.top()+1,y-15)
                p.setPen(QColor("#7EC4FF"))
                p.drawText(QRectF(x-36,yy,72,12),Qt.AlignCenter,f"F {freighter_vals[-1]*100:.1f}%")

            if pax_vals:
                x=xs[-1]; y=pax_ys[-1]
                yy=min(rect.bottom()-12,y+5)
                p.setPen(QColor("#FF8A90"))
                p.drawText(QRectF(x-36,yy,72,12),Qt.AlignCenter,f"P {pax_vals[-1]*100:.1f}%")

            # X labels
            p.setPen(QColor("#CBD7E1"))
            f=QFont(); f.setPointSize(6); p.setFont(f)
            for lab,x in zip(labels,xs):
                p.drawText(QRectF(x-25,rect.bottom()+3,50,16),Qt.AlignCenter,str(lab))

        p.end()
        self.lf_view.setPixmap(pm)

    def _render_source_pixmap(self,awbs):
        online=int((awbs["Source"].astype(str).str.lower()=="onlinesales").sum()) if not awbs.empty else 0
        other=max(0,len(awbs)-online); total=online+other
        pm=self._chart_canvas(self.source_view,205,132); p=QPainter(pm); p.setRenderHint(QPainter.Antialiasing,True)
        dpr=pm.devicePixelRatio(); lw=pm.width()/dpr; lh=pm.height()/dpr

        c=QPointF(lw*0.31,lh*0.47)
        outer=min(lw,lh)*.31; inner=outer*.58
        ringw=outer-inner; mid=(outer+inner)/2
        ringbox=QRectF(c.x()-mid,c.y()-mid,2*mid,2*mid)
        if total:
            op=online/total
            p.setPen(QPen(QColor("#E3161C"),ringw)); p.drawArc(ringbox,90*16,-op*360*16)
            p.setPen(QPen(QColor("#F47B0B"),ringw)); p.drawArc(ringbox,(90-op*360)*16,-(1-op)*360*16)

            p.setPen(QColor("#FFFFFF")); f=QFont(); f.setPointSize(12); f.setBold(True); p.setFont(f)
            p.drawText(QRectF(c.x()-40,c.y()-16,80,20),Qt.AlignCenter,f"{total:,}")
            f.setPointSize(7); f.setBold(False); p.setFont(f)
            p.drawText(QRectF(c.x()-40,c.y()+2,80,15),Qt.AlignCenter,"AWBs")

            lx=lw*.57; ly=lh*.31
            p.fillRect(QRectF(lx,ly,9,9),QColor("#E3161C"))
            p.fillRect(QRectF(lx,ly+28,9,9),QColor("#F47B0B"))
            p.setPen(QColor("#E8EEF5")); f.setPointSize(6); f.setBold(True); p.setFont(f)
            p.drawText(QPointF(lx+14,ly+8),f"OnlineSales   {online:,}  •  {op:.1%}")
            p.drawText(QPointF(lx+14,ly+36),f"iCargo / Other   {other:,}  •  {1-op:.1%}")
        p.end(); self.source_view.setPixmap(pm)

    def build_trend_charts(self,period,year,week,month,view):
        points=[]
        if period=="Weekly":
            for w in range(max(1,week-7),week+1):
                a,f=filter_period(self.data,"Weekly",year,week=w,view=view)
                a,f=self._apply_extra_filters(a,f)
                points.append((f"W{w}",kpis(a,f)))
        elif period=="Monthly":
            for m in range(max(1,month-7),month+1):
                a,f=filter_period(self.data,"Monthly",year,month=m,view=view)
                a,f=self._apply_extra_filters(a,f)
                points.append((pd.Timestamp(year=year,month=m,day=1).strftime("%b"),kpis(a,f)))
        else:
            for yv in range(year-4,year+1):
                a,f=filter_period(self.data,"Yearly",yv,view=view)
                a,f=self._apply_extra_filters(a,f)
                points.append((str(yv),kpis(a,f)))

        self._trend_hover_data={"cw":points,"revenue":points,"lf":points,"view":view}
        self._render_cw_pixmap(points)
        self._render_revenue_pixmap(points)
        self._render_lf_pixmap(points,view)

    def build_source_chart(self,awbs):
        online=int((awbs["Source"].astype(str).str.lower()=="onlinesales").sum()) if not awbs.empty else 0
        other=max(0,len(awbs)-online); total=online+other
        online_pct=(online/total*100) if total else 0
        other_pct=(other/total*100) if total else 0
        self.source_legend.setText(
            f"OnlineSales — {online:,} AWBs ({online_pct:.1f}%)   •   "
            f"iCargo / Other — {other:,} AWBs ({other_pct:.1f}%)"
        )
        self._render_source_pixmap(awbs)



def main():
    app=QApplication(sys.argv)
    app.setStyleSheet(QSS)
    w=MainWindow(); w.show()
    sys.exit(app.exec())

if __name__=="__main__":
    main()
