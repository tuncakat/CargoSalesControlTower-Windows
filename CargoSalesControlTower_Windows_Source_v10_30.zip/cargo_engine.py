
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import pandas as pd

# Fallback capacities for the latest/current pattern.
FREIGHTER_CAPACITY = {
    ("TK6505", 2): 16100,
    ("TK6467", 3): 32200,
    ("TK6512", 4): 17500,
    ("TK6513", 4): 16100,
    ("TK6543", 5): 16100,
    ("TK6504", 7): 17500,
    ("TK6545", 7): 16100,
}

# Date-range capacity rules for CPH-IST.
# Later rules override earlier overlapping schedule versions.
# Source: S26 Schedule & Allocation Share.xlsx, W25/S26/S26 UPD...UPD5.
FREIGHTER_CAPACITY_RULES = [
    # W25 — Jan to Mar 2026
    ("TK6504", 4, "2026-01-01", "2026-03-26", 15750),  # ARNIST 7SBS+1LD+2PLA
    ("TK6504", 6, "2026-01-03", "2026-03-28", 15750),  # ARNIST 7SBS+1LD+2PLA
    ("TK6547", 6, "2026-01-03", "2026-03-28", 16100),  # ARNIST 6SBS+2LD — inferred from W25 pattern
    ("TK6545", 7, "2026-01-04", "2026-03-22", 14490),  # ARNIST 5SBS+2LD
    ("TK6445", 3, "2026-01-07", "2026-03-25", 14490),  # ARNIST 5SBS+2LD

    # S26 / latest applicable revisions
    ("TK6545", 7, "2026-03-29", "2026-03-29", 14490),
    ("TK6504", 2, "2026-03-31", "2026-04-28", 15750),
    ("TK6512", 4, "2026-04-02", "2026-04-30", 28980),

    # UPD2/UPD3 retroactively supersede the earlier 14,490 rules
    ("TK6513", 4, "2026-04-02", "2026-07-02", 16100),
    ("TK6543", 5, "2026-04-03", "2026-06-26", 16100),
    ("TK6504", 7, "2026-04-05", "2026-04-26", 15750),
    ("TK6545", 7, "2026-04-05", "2026-06-28", 16100),

    # May
    ("TK6504", 7, "2026-05-03", "2026-05-31", 25760),
    ("TK6504", 2, "2026-05-05", "2026-06-16", 11250),
    ("TK6467", 3, "2026-05-06", "2026-05-27", 26080),  # USER-CONFIRMED ARN allocation
    ("TK6512", 4, "2026-05-07", "2026-06-18", 29000),

    # June
    ("TK6467", 3, "2026-06-03", "2026-06-17", 32200),
    ("TK6504", 7, "2026-06-07", "2026-06-28", 17500),
    ("TK6504", 2, "2026-06-23", "2026-06-23", 15750),
    ("TK6512", 4, "2026-06-25", "2026-07-02", 32200),
    ("TK6504", 2, "2026-06-30", "2026-07-07", 17500),

    # July
    ("TK6543", 5, "2026-07-03", "2026-07-24", 16100),
    ("TK6504", 7, "2026-07-05", "2026-07-26", 17500),
    ("TK6545", 7, "2026-07-05", "2026-07-26", 16100),
    ("TK6505", 2, "2026-07-07", "2026-07-28", 16100),
    ("TK6512", 4, "2026-07-09", "2026-07-30", 32200),
    ("TK6513", 4, "2026-07-09", "2026-07-30", 16100),
    ("TK6504", 2, "2026-07-14", "2026-07-28", 15750),
    ("TK6467", 3, "2026-07-15", "2026-07-29", 32200),

    # August
    ("TK6543", 5, "2026-07-31", "2026-08-28", 16100),
    ("TK6504", 7, "2026-08-02", "2026-08-30", 17500),
    ("TK6545", 7, "2026-08-02", "2026-08-30", 16100),
    ("TK6504", 2, "2026-08-04", "2026-10-20", 17500),
    ("TK6467", 3, "2026-08-05", "2026-08-26", 32200),
    ("TK6512", 4, "2026-08-06", "2026-08-27", 17500),
    ("TK6513", 4, "2026-08-06", "2026-08-27", 16100),

    # September / October reversion after temporary August aircraft swaps
    ("TK6512", 4, "2026-09-03", "2026-10-22", 32200),
    ("TK6513", 4, "2026-09-03", "2026-10-22", 16100),
    ("TK6543", 5, "2026-09-04", "2026-10-23", 16100),
    ("TK6504", 7, "2026-09-06", "2026-10-18", 17500),
    ("TK6545", 7, "2026-09-06", "2026-10-18", 16100),
]


# One-off operational exceptions.
CAPACITY_EXCEPTIONS = {
    (pd.Timestamp("2026-08-15").date(), "TK1796", "ARN-IST"): 10000,
}

FOCUS_FREIGHTER_SECTOR = ("CPH", "IST")
FOCUS_PAX_SECTORS = {("ARN", "IST"), ("GOT", "IST")}

@dataclass
class DashboardData:
    awbs: pd.DataFrame
    flights: pd.DataFrame
    import_quality: dict | None = None

def _parse_number(value) -> float:
    if pd.isna(value):
        return 0.0
    text = str(value).replace("\xa0", " ").strip()
    m = re.search(r"[-+]?\d[\d,]*(?:\.\d+)?", text)
    if not m:
        return 0.0
    try:
        return float(m.group(0).replace(",", ""))
    except ValueError:
        return 0.0

def _parse_currency(value) -> str:
    if pd.isna(value):
        return ""
    text = str(value).upper()
    m = re.search(r"\b([A-Z]{3})\b", text)
    return m.group(1) if m else ""


def _normalize_agent_name(value) -> str:
    """Conservatively collapse obvious aliases of the same forwarding company."""
    if pd.isna(value):
        return ""
    raw = re.sub(r"\s+", " ", str(value)).strip()
    key = re.sub(r"[^A-Z0-9]+", " ", raw.upper()).strip()

    # Known COMIS aliases that should be presented as one commercial account.
    if "KUEHNE" in key and "NAGEL" in key:
        return "KUEHNE+NAGEL"
    if key.startswith("DSV ") or key == "DSV":
        return "DSV AIR & SEA"
    if "DHL GLOBAL FORWARDING" in key:
        return "DHL GLOBAL FORWARDING"
    if "GEODIS" in key:
        return "GEODIS"
    if "SCAN GLOBAL" in key:
        return "SCAN GLOBAL LOGISTICS"

    return raw

def _cargo_category_from_scc(value) -> str:
    """Classify COMIS SCC: PIL=Pharma, GEN=General Cargo; PIL takes precedence."""
    text = str(value or "").upper()
    codes = {x.strip() for x in re.split(r"[,;/|\s]+", text) if x.strip()}
    if "PIL" in codes:
        return "Pharma"
    if "GEN" in codes:
        return "General Cargo"
    return "Other"

def _normalize_awb(value) -> str:
    if pd.isna(value):
        return ""
    text = str(value).replace("\xa0", " ")
    text = re.sub(r"\s+", "", text)
    text = text.replace("-", "")
    if len(text) >= 11 and text[:3].isdigit():
        return f"{text[:3]}-{text[-8:]}"
    return str(value).strip()

def _parse_segment(text: str):
    if not text:
        return None, None
    m = re.search(r"\b(TK\d{4}[A-Z]?)\b\s*\|\s*(\d{1,2}-[A-Za-z]{3}-\d{4})", str(text))
    if not m:
        return None, None
    flight = m.group(1)
    # Remove suffix letter from truck flight number for class rules, retain display code.
    date = pd.to_datetime(m.group(2), format="%d-%b-%Y", errors="coerce")
    return flight, date

def _flight_numeric(flight: str) -> Optional[int]:
    m = re.search(r"TK(\d{4})", str(flight))
    return int(m.group(1)) if m else None

def _classify_flight(flight: str) -> str:
    n = _flight_numeric(flight)
    if n is None:
        return "Other"
    if 6000 <= n <= 6999:
        return "Freighter"
    if 0 <= n <= 1999:
        return "Passenger"
    if 2000 <= n <= 2999 or 8000 <= n <= 9999:
        return "Truck"
    return "Other"

def _capacity_for(flight_date, flight: str, sector: str, flight_type: str) -> float:
    if pd.isna(flight_date):
        return 0.0
    dt = pd.Timestamp(flight_date)
    dow = dt.isoweekday()
    key = (dt.date(), flight, sector)
    if key in CAPACITY_EXCEPTIONS:
        return float(CAPACITY_EXCEPTIONS[key])

    if flight_type == "Freighter" and sector == "CPH-IST":
        # Date-range rules are checked newest-to-oldest so schedule updates
        # supersede earlier overlapping rules.
        for rule_flight, rule_dow, start_s, end_s, capacity in reversed(FREIGHTER_CAPACITY_RULES):
            if flight != rule_flight or dow != rule_dow:
                continue
            start_dt = pd.Timestamp(start_s).date()
            end_dt = pd.Timestamp(end_s).date()
            if start_dt <= dt.date() <= end_dt:
                return float(capacity)

        # Fallback for current/latest schedule beyond the explicit rule horizon.
        return float(FREIGHTER_CAPACITY.get((flight, dow), 0))

    if flight_type == "Passenger" and sector == "ARN-IST":
        return 1000.0

    if flight_type == "Passenger" and sector == "GOT-IST":
        return 1000.0 if dow <= 5 else 0.0

    return 0.0

def load_comis_booking_list(path: str | Path, sek_to_usd: float = 0.104965) -> DashboardData:
    path = Path(path)
    raw = pd.read_excel(path, sheet_name=0, header=0, engine="openpyxl")

    # COMIS export contains one master row per AWB followed by segment rows where AWB is blank.
    records = []
    current = None

    for _, row in raw.iterrows():
        awb_value = row.get("AWB No.")
        if pd.notna(awb_value):
            if current is not None:
                records.append(current)
            current = {
                "AWB": _normalize_awb(awb_value),
                "Agent Code": row.get("Agent Code"),
                "Agent": _normalize_agent_name(row.get("Agent Name")),
                "Origin": str(row.get("Origin", "")).strip(),
                "Destination": str(row.get("Destination", "")).strip(),
                "Source": str(row.get("Source", "")).strip(),
                "CW KG": _parse_number(row.get("Chargeable Weight")),
                "Revenue Original": _parse_number(row.get("Charge")),
                "Currency": _parse_currency(row.get("Charge")),
                "Booking Date": pd.to_datetime(row.get("Booking Date"), errors="coerce"),
                "Shipping Date": pd.to_datetime(row.get("Shipping Date"), errors="coerce"),
                "Product": row.get("Product"),
                "Commodity": row.get("Commodity"),
                "SCC": str(row.get("SCC", "") or "").strip(),
                "Pieces": _parse_number(row.get("Booked/Pcs")),
                "Shipment Details": row.get("Shipment Details"),
                "Booking Status": row.get("Booking Status"),
                "_segments": [],
            }
            # The first AWB row also contains a concatenated flight chain. The expanded rows
            # below are preferred because they include origin/destination per segment.
        else:
            if current is None:
                continue
            flight_text = row.get("Flight Details")
            flight, date = _parse_segment(flight_text)
            if flight:
                seg_origin = str(row.get("Origin", "")).strip()
                seg_dest = str(row.get("Destination", "")).strip()
                current["_segments"].append({
                    "flight": flight,
                    "date": date,
                    "origin": seg_origin,
                    "destination": seg_dest,
                    "type": _classify_flight(flight),
                })

    if current is not None:
        records.append(current)

    # Automatic COMIS duplicate cleaning.
    # A repeated AWB block in the same/later export is one commercial shipment,
    # not additional tonnage. Keep the latest occurrence as the authoritative revision.
    raw_record_count = len(records)
    raw_cw = sum(float(r.get("CW KG", 0) or 0) for r in records)
    latest_by_awb = {}
    duplicate_rows = []
    for pos, r in enumerate(records):
        key = r.get("AWB", "")
        if key in latest_by_awb:
            old_pos, old = latest_by_awb[key]
            duplicate_rows.append({
                "AWB": key,
                "Removed CW KG": float(old.get("CW KG", 0) or 0),
                "Old Position": old_pos + 1,
                "Kept Position": pos + 1,
            })
        latest_by_awb[key] = (pos, r)

    records = [x[1] for x in sorted(latest_by_awb.values(), key=lambda x: x[0])]
    duplicate_cw_removed = sum(x["Removed CW KG"] for x in duplicate_rows)

    clean = []
    for r in records:
        currency = r["Currency"]
        rev_original = r["Revenue Original"]
        if currency == "SEK":
            revenue_usd = rev_original * sek_to_usd
        elif currency == "USD":
            revenue_usd = rev_original
        else:
            # Unknown currencies are kept at zero until an explicit FX rule is supplied.
            revenue_usd = 0.0

        primary = None
        # Priority 1: CPH-IST freighter.
        for s in r["_segments"]:
            if (s["origin"], s["destination"]) == FOCUS_FREIGHTER_SECTOR and s["type"] == "Freighter":
                primary = s
                break
        # Priority 2: ARN/GOT-IST passenger.
        if primary is None:
            for s in r["_segments"]:
                if (s["origin"], s["destination"]) in FOCUS_PAX_SECTORS and s["type"] == "Passenger":
                    primary = s
                    break

        # Fallback: parse concatenated chain is intentionally avoided for focused capacity metrics.
        flight = primary["flight"] if primary else ""
        flight_date = primary["date"] if primary else pd.NaT
        flight_type = primary["type"] if primary else "Other"
        sector = f'{primary["origin"]}-{primary["destination"]}' if primary else ""

        # Sales-period attribution must follow the shipment's first departure from Sweden.
        # Do NOT move a June shipment into July merely because its CPH-IST freighter segment
        # operated in July. Flight Performance still uses the actual selected operating segment.
        sales_seg = None
        for s in r["_segments"]:
            if s["origin"] in {"ARN", "GOT", "MMX"}:
                sales_seg = s
                break
        sales_date = sales_seg["date"] if sales_seg is not None else flight_date

        cw = float(r["CW KG"])
        clean.append({
            **{k:v for k,v in r.items() if k != "_segments"},
            "Revenue USD": revenue_usd,
            "UR USD/kg": revenue_usd / cw if cw else 0.0,
            "Cargo Category": _cargo_category_from_scc(r.get("SCC", "")),
            "Sales Date": sales_date,
            "Primary Flight": flight,
            "Flight Date": flight_date,
            "Flight Type": flight_type,
            "Sector": sector,
            "DOW": f"D{pd.Timestamp(flight_date).isoweekday()}" if pd.notna(flight_date) else "",
            "ISO Week": int(pd.Timestamp(sales_date).isocalendar().week) if pd.notna(sales_date) else None,
            "Year": int(pd.Timestamp(sales_date).isocalendar().year) if pd.notna(sales_date) else None,
        })

    awbs = pd.DataFrame(clean)
    if awbs.empty:
        return DashboardData(awbs=awbs, flights=pd.DataFrame(), import_quality={
            "raw_awbs": raw_record_count,
            "clean_awbs": len(records),
            "duplicates_removed": len(duplicate_rows),
            "duplicate_cw_removed": duplicate_cw_removed,
            "raw_cw": raw_cw,
        })

    # Focused dashboard data only: CPH-IST freighter + ARN/GOT-IST passenger.
    focused = awbs[awbs["Flight Type"].isin(["Freighter", "Passenger"]) & awbs["Primary Flight"].ne("")].copy()

    agg = focused.groupby(
        ["Flight Date", "DOW", "Primary Flight", "Flight Type", "Sector"],
        dropna=False,
        as_index=False
    ).agg({
        "CW KG": "sum",
        "Revenue USD": "sum",
        "AWB": "count",
    }).rename(columns={
        "Primary Flight": "Flight",
        "CW KG": "Booked CW KG",
        "AWB": "AWBs",
    })

    agg["Capacity KG"] = agg.apply(
        lambda x: _capacity_for(x["Flight Date"], x["Flight"], x["Sector"], x["Flight Type"]),
        axis=1
    )
    agg["LF %"] = agg.apply(
        lambda x: x["Booked CW KG"] / x["Capacity KG"] if x["Capacity KG"] > 0 else None,
        axis=1
    )
    agg["Gap KG"] = agg["Capacity KG"] - agg["Booked CW KG"]
    agg["UR USD/kg"] = agg.apply(
        lambda x: x["Revenue USD"] / x["Booked CW KG"] if x["Booked CW KG"] else 0.0,
        axis=1
    )

    def status(row):
        if row["Capacity KG"] <= 0:
            return "NO CAPACITY"
        lf = row["LF %"]
        if lf is None:
            return "NO CAPACITY"
        if lf > 1:
            return "OVERBOOKED"
        if lf >= .90:
            return "HIGH LF"
        if lf < .60:
            return "LOW LF"
        return "OK"

    agg["Status"] = agg.apply(status, axis=1)
    agg = agg.sort_values(["Flight Date", "Flight"]).reset_index(drop=True)
    return DashboardData(
        awbs=awbs,
        flights=agg,
        import_quality={
            "raw_awbs": raw_record_count,
            "clean_awbs": len(records),
            "duplicates_removed": len(duplicate_rows),
            "duplicate_cw_removed": duplicate_cw_removed,
            "raw_cw": raw_cw,
            "clean_cw": float(awbs["CW KG"].sum()) if not awbs.empty else 0.0,
            "duplicate_log": duplicate_rows,
        }
    )


def _aggregate_flights_from_awbs(awbs: pd.DataFrame) -> pd.DataFrame:
    if awbs.empty:
        return pd.DataFrame()
    focused = awbs[awbs["Flight Type"].isin(["Freighter", "Passenger"]) & awbs["Primary Flight"].ne("")].copy()
    if focused.empty:
        return pd.DataFrame()
    agg = focused.groupby(["Flight Date", "DOW", "Primary Flight", "Flight Type", "Sector"], dropna=False, as_index=False).agg({
        "CW KG": "sum", "Revenue USD": "sum", "AWB": "count",
    }).rename(columns={"Primary Flight":"Flight","CW KG":"Booked CW KG","AWB":"AWBs"})
    agg["Capacity KG"] = agg.apply(lambda x: _capacity_for(x["Flight Date"], x["Flight"], x["Sector"], x["Flight Type"]), axis=1)
    agg["LF %"] = agg.apply(lambda x: x["Booked CW KG"] / x["Capacity KG"] if x["Capacity KG"] > 0 else None, axis=1)
    agg["Gap KG"] = agg["Capacity KG"] - agg["Booked CW KG"]
    agg["UR USD/kg"] = agg.apply(lambda x: x["Revenue USD"] / x["Booked CW KG"] if x["Booked CW KG"] else 0.0, axis=1)
    def status(row):
        if row["Capacity KG"] <= 0: return "NO CAPACITY"
        lf = row["LF %"]
        if lf is None: return "NO CAPACITY"
        if lf > 1: return "OVERBOOKED"
        if lf >= .90: return "HIGH LF"
        if lf < .60: return "LOW LF"
        return "OK"
    agg["Status"] = agg.apply(status, axis=1)
    return agg.sort_values(["Flight Date", "Flight"]).reset_index(drop=True)


def load_comis_booking_lists(paths, sek_to_usd: float = 0.104965) -> DashboardData:
    paths = [Path(p) for p in paths]
    if not paths:
        return DashboardData(pd.DataFrame(), pd.DataFrame(), import_quality={})
    all_awbs=[]; file_reports=[]
    for order,path in enumerate(paths):
        data=load_comis_booking_list(path, sek_to_usd=sek_to_usd)
        a=data.awbs.copy(); a['_file_order']=order; a['_source_file']=path.name
        all_awbs.append(a)
        iq=data.import_quality or {}
        file_reports.append({
            'file':path.name,
            'raw_awbs':int(iq.get('raw_awbs',len(a))),
            'clean_awbs':int(iq.get('clean_awbs',len(a))),
            'duplicates_removed':int(iq.get('duplicates_removed',0)),
            'duplicate_cw_removed':float(iq.get('duplicate_cw_removed',0.0)),
        })
    combined=pd.concat(all_awbs, ignore_index=True) if all_awbs else pd.DataFrame()
    if combined.empty:
        return DashboardData(combined,pd.DataFrame(),import_quality={'files':len(paths),'file_reports':file_reports})
    dupmask=combined.duplicated(subset=['AWB'], keep='last')
    dupes=combined.loc[dupmask].copy()
    removed=len(dupes); removed_cw=float(dupes['CW KG'].sum()) if not dupes.empty else 0.0
    merged=combined.loc[~dupmask].copy().sort_values('_file_order').reset_index(drop=True)
    keep_map=(combined.loc[~combined.duplicated(subset=['AWB'], keep='last'),['AWB','_source_file']].set_index('AWB')['_source_file'].to_dict())
    dlog=[]
    for _,r in dupes.iterrows():
        dlog.append({'AWB':r['AWB'],'Removed From':r['_source_file'],'Kept From':keep_map.get(r['AWB'],''),'Removed CW KG':float(r['CW KG']),'Reason':'Same AWB found in multiple imports; later file retained'})
    merged=merged.drop(columns=['_file_order'], errors='ignore')
    flights=_aggregate_flights_from_awbs(merged)
    within=sum(x['duplicates_removed'] for x in file_reports)
    within_cw=sum(x['duplicate_cw_removed'] for x in file_reports)
    iq={'files':len(paths),'file_reports':file_reports,'master_awbs':len(merged),'cross_file_duplicates_removed':removed,'cross_file_duplicate_cw_removed':removed_cw,'within_file_duplicates_removed':within,'within_file_duplicate_cw_removed':within_cw,'total_duplicates_removed':within+removed,'total_duplicate_cw_removed':within_cw+removed_cw,'master_cw':float(merged['CW KG'].sum()),'duplicate_log':dlog}
    return DashboardData(awbs=merged,flights=flights,import_quality=iq)

def available_periods(data: DashboardData):
    if data.flights.empty:
        return [], []
    years = sorted(data.flights["Flight Date"].dropna().dt.isocalendar().year.astype(int).unique().tolist())
    weeks = sorted(data.flights["Flight Date"].dropna().dt.isocalendar().week.astype(int).unique().tolist())
    return years, weeks

def filter_data(data: DashboardData, year: int, week: int, view: str = "All"):
    f = data.flights.copy()
    a = data.awbs.copy()
    if f.empty:
        return a.iloc[0:0], f

    iso = f["Flight Date"].dt.isocalendar()
    mask = (iso.year.astype(int) == int(year)) & (iso.week.astype(int) == int(week))
    f = f[mask].copy()

    if view == "Freighter":
        f = f[f["Flight Type"] == "Freighter"].copy()
    elif view == "Pax":
        f = f[f["Flight Type"] == "Passenger"].copy()

    if f.empty:
        return a.iloc[0:0], f

    keys = set(zip(f["Flight Date"], f["Flight"]))
    a = a[a.apply(lambda r: (r["Flight Date"], r["Primary Flight"]) in keys, axis=1)].copy()
    return a, f

def kpis(awbs: pd.DataFrame, flights: pd.DataFrame):
    cw = float(awbs["CW KG"].sum()) if not awbs.empty else 0.0
    revenue = float(awbs["Revenue USD"].sum()) if not awbs.empty else 0.0
    ur = revenue / cw if cw else 0.0
    capacity = float(flights["Capacity KG"].sum()) if not flights.empty else 0.0
    lf = cw / capacity if capacity else 0.0

    freight = awbs[awbs["Flight Type"] == "Freighter"] if not awbs.empty else awbs
    pax = awbs[awbs["Flight Type"] == "Passenger"] if not awbs.empty else awbs

    def ur_of(df):
        c = float(df["CW KG"].sum()) if not df.empty else 0.0
        r = float(df["Revenue USD"].sum()) if not df.empty else 0.0
        return r/c if c else 0.0

    ff = flights[flights["Flight Type"] == "Freighter"] if not flights.empty else flights
    pf = flights[flights["Flight Type"] == "Passenger"] if not flights.empty else flights
    freight_cw = float(freight["CW KG"].sum()) if not freight.empty else 0.0
    pax_cw = float(pax["CW KG"].sum()) if not pax.empty else 0.0
    freight_cap = float(ff["Capacity KG"].sum()) if not ff.empty else 0.0
    pax_cap = float(pf["Capacity KG"].sum()) if not pf.empty else 0.0

    online = 0.0
    pharma_share = 0.0
    general_share = 0.0
    pharma_tonnage = 0.0
    if not awbs.empty:
        online = float((awbs["Source"].str.lower() == "onlinesales").sum()) / len(awbs)
        total_cw = float(awbs["CW KG"].sum())
        if total_cw > 0 and "Cargo Category" in awbs.columns:
            pharma_cw = float(awbs.loc[awbs["Cargo Category"]=="Pharma","CW KG"].sum())
            pharma_share = pharma_cw / total_cw
            pharma_tonnage = pharma_cw / 1000.0
            general_share = float(awbs.loc[awbs["Cargo Category"]=="General Cargo","CW KG"].sum()) / total_cw

    return {
        "Booked CW": cw,
        "Revenue": revenue,
        "Overall UR": ur,
        "Overall LF": lf,
        "AWBs": len(awbs),
        "Online Share": online,
        "Freighter LF": freight_cw/freight_cap if freight_cap else 0.0,
        "Pax LF": pax_cw/pax_cap if pax_cap else 0.0,
        "Freighter UR": ur_of(freight),
        "Pax UR": ur_of(pax),
        "Pharma Share": pharma_share,
        "Pharma Tonnage": pharma_tonnage,
        "General Cargo Share": general_share,
    }

def agent_performance(awbs: pd.DataFrame):
    if awbs.empty:
        return pd.DataFrame(columns=["Agent","CW KG","Revenue USD","UR USD/kg","AWBs"])
    x = awbs.groupby("Agent", dropna=False, as_index=False).agg({
        "CW KG":"sum","Revenue USD":"sum","AWB":"count"
    }).rename(columns={"AWB":"AWBs"})
    x["UR USD/kg"] = x.apply(lambda r: r["Revenue USD"]/r["CW KG"] if r["CW KG"] else 0, axis=1)
    return x.sort_values("CW KG", ascending=False)

def destination_performance(awbs: pd.DataFrame):
    if awbs.empty:
        return pd.DataFrame(columns=["Destination","CW KG","Revenue USD","UR USD/kg","AWBs"])
    x = awbs.groupby("Destination", dropna=False, as_index=False).agg({
        "CW KG":"sum","Revenue USD":"sum","AWB":"count"
    }).rename(columns={"AWB":"AWBs"})
    x["UR USD/kg"] = x.apply(lambda r: r["Revenue USD"]/r["CW KG"] if r["CW KG"] else 0, axis=1)
    return x.sort_values("CW KG", ascending=False)

def recommended_actions(flights: pd.DataFrame, agents: pd.DataFrame):
    actions = []
    if not flights.empty:
        for _, r in flights.iterrows():
            if r["Status"] == "OVERBOOKED":
                actions.append(("Capacity Risk", "HIGH",
                    f'{r["Flight"]} {pd.Timestamp(r["Flight Date"]).strftime("%d %b")}: '
                    f'{r["Booked CW KG"]:,.0f} kg booked vs {r["Capacity KG"]:,.0f} kg capacity '
                    f'({r["LF %"]:.0%} LF). Review offload/payload risk.'))
            elif r["Status"] == "LOW LF" and r["Capacity KG"] > 0:
                actions.append(("Sales Opportunity", "MEDIUM",
                    f'{r["Flight"]} {pd.Timestamp(r["Flight Date"]).strftime("%d %b")}: '
                    f'LF {r["LF %"]:.0%}, {max(r["Gap KG"],0):,.0f} kg open capacity. Prioritize sales pull-forward.'))

    if not agents.empty:
        top = agents.iloc[0]
        actions.append(("Top Account", "INFO",
            f'{top["Agent"]}: {top["CW KG"]:,.0f} kg and ${top["Revenue USD"]:,.0f} revenue in selected period.'))
    return actions[:12]


MONTH_NAMES = {
    1:"January",2:"February",3:"March",4:"April",5:"May",6:"June",
    7:"July",8:"August",9:"September",10:"October",11:"November",12:"December"
}

def filter_period(data: DashboardData, period: str, year: int, week: int | None = None,
                  month: int | None = None, view: str = "All"):
    f = data.flights.copy()
    a = data.awbs.copy()
    period = (period or "Weekly").title()

    # Commercial period uses first Sweden departure (Sales Date).
    if a.empty:
        sales_date = pd.Series(pd.NaT, index=a.index)
    else:
        sales_date = pd.to_datetime(
            a["Sales Date"] if "Sales Date" in a.columns else a["Flight Date"],
            errors="coerce"
        )

    if period == "Weekly":
        if week is None:
            return a.iloc[0:0], f.iloc[0:0]
        ai = sales_date.dt.isocalendar()
        amask = (ai.year.astype("Int64") == int(year)) & (ai.week.astype("Int64") == int(week))
    elif period == "Monthly":
        if month is None:
            return a.iloc[0:0], f.iloc[0:0]
        amask = (sales_date.dt.year == int(year)) & (sales_date.dt.month == int(month))
    elif period == "Yearly":
        amask = sales_date.dt.year == int(year)
    else:
        amask = pd.Series(False, index=a.index)

    a = a[amask.fillna(False)].copy()

    if view == "Freighter":
        a = a[a["Flight Type"] == "Freighter"].copy()
    elif view == "Pax":
        a = a[a["Flight Type"] == "Passenger"].copy()

    # Flight Performance/LF uses operating Flight Date.
    if f.empty:
        return a, f

    fdate = pd.to_datetime(f["Flight Date"], errors="coerce")
    if period == "Weekly":
        fi = fdate.dt.isocalendar()
        fmask = (fi.year.astype("Int64") == int(year)) & (fi.week.astype("Int64") == int(week))
    elif period == "Monthly":
        fmask = (fdate.dt.year == int(year)) & (fdate.dt.month == int(month))
    elif period == "Yearly":
        fmask = fdate.dt.year == int(year)
    else:
        fmask = pd.Series(False, index=f.index)

    f = f[fmask.fillna(False)].copy()
    if view == "Freighter":
        f = f[f["Flight Type"] == "Freighter"].copy()
    elif view == "Pax":
        f = f[f["Flight Type"] == "Passenger"].copy()

    return a, f

